
import React, { createContext, useState, useEffect, useContext } from 'react';
import { HashRouter, Routes, Route, Navigate } from 'react-router-dom';
import { initializeApp } from "firebase/app";
import { 
  getFirestore, collection, onSnapshot, addDoc, updateDoc, deleteDoc, doc, 
  query, serverTimestamp, where, setDoc, getDoc, getDocs, limit, orderBy
} from "firebase/firestore";
import { 
  getAuth, onAuthStateChanged, signOut, User as FirebaseUser 
} from "firebase/auth";

import { Layout } from './components/Layout';
import { LoginPage } from './components/LoginPage';
import { Dashboard } from './pages/Dashboard';
import { Sales } from './pages/Sales';
import { Marketing } from './pages/Marketing';
import { Finance } from './pages/Finance';
import { Team } from './pages/Team';
import { GoalsAndTasks } from './pages/GoalsAndTasks';
import { AppContextType, AppState, User, UserAccess, Task, TaskStatus, Goal, Sale, DailyMetric, Campaign, AdSet, Creative, Transaction, CardConfig, DebtContract } from './types';
import { INITIAL_STATE, getNextOccurrenceDate } from './constants';
import { Lock } from 'lucide-react';

const firebaseConfig = {
  apiKey: "AIzaSyA5cwwkiNBGwwluR6bFNzBJOFUF46l-1vY",
  authDomain: "gen-lang-client-0466296163.firebaseapp.com",
  projectId: "gen-lang-client-0466296163",
  storageBucket: "gen-lang-client-0466296163.firebasestorage.app",
  messagingSenderId: "910407281312",
  appId: "1:910407281312:web:3161e0d86cfbea8283b7c5",
  measurementId: "G-DJNKLEJ6DY"
};

const firebaseApp = initializeApp(firebaseConfig);
const db = getFirestore(firebaseApp);
const auth = getAuth(firebaseApp);

const deepClean = (obj: any): any => {
    return JSON.parse(JSON.stringify(obj, (key, value) => {
        if (value === undefined || key === 'id') return undefined;
        return value;
    }));
};

const FULL_ACCESS: UserAccess = {
  dashboard: true,
  sales: true,
  marketing: true,
  finance: true,
  team: true,
  goals: true,
};

const RESTRICTED_ACCESS: UserAccess = {
  dashboard: true,
  sales: false,
  marketing: false,
  finance: false,
  team: false,
  goals: false,
};

export const AppContext = createContext<AppContextType & { logout: () => void; can: (key: keyof UserAccess) => boolean; profileReady: boolean }>({} as any);

const ProtectedRoute: React.FC<{ children: React.ReactNode; module: keyof UserAccess }> = ({ children, module }) => {
  const { can, profileReady, currentUser } = useContext(AppContext);
  if (!profileReady) return (
    <div className="flex flex-col items-center justify-center h-screen bg-slate-50">
        <div className="animate-spin rounded-full h-10 w-10 border-b-2 border-brand-600 mb-4"></div>
        <p className="text-slate-500 font-bold">Verificando permissões...</p>
    </div>
  );
  if (!currentUser) return <Navigate to="/" />;
  if (!can(module)) return (
    <div className="flex flex-col items-center justify-center h-[60vh] text-center p-6 bg-white rounded-3xl border border-slate-100 mx-4 shadow-sm">
        <div className="bg-red-50 p-4 rounded-full mb-4">
          <Lock size={48} className="text-red-500" />
        </div>
        <h2 className="text-xl font-bold text-slate-800">Módulo Bloqueado</h2>
        <p className="text-slate-500 mt-2 max-w-xs text-sm">Você ainda não tem permissão para acessar este módulo.</p>
    </div>
  );
  return <>{children}</>;
};

const App = () => {
  const [firebaseUser, setFirebaseUser] = useState<FirebaseUser | null>(null);
  const [authLoading, setAuthLoading] = useState(true);
  const [profileReady, setProfileReady] = useState(false);
  const [state, setState] = useState<AppState>(() => ({ 
    ...INITIAL_STATE, 
    transactions: [], 
    debtContracts: [], 
    cards: [] 
  }));

  useEffect(() => {
    return onAuthStateChanged(auth, (fUser) => {
      setFirebaseUser(fUser);
      if (!fUser) {
        setProfileReady(false);
        setAuthLoading(false);
      }
    });
  }, []);

  useEffect(() => {
    if (!firebaseUser) return;
    const initProfile = async () => {
        const userDocRef = doc(db, "users", firebaseUser.uid);
        const userEmail = firebaseUser.email?.toLowerCase();
        const owners = ['mateus@ekoanatural.com'];
        const isOwner = owners.includes(userEmail || '');
        const docSnap = await getDoc(userDocRef);
        let userData: User;
        if (docSnap.exists()) {
            userData = { ...docSnap.data() as User, id: firebaseUser.uid };
        } else {
            userData = {
                id: firebaseUser.uid,
                name: firebaseUser.displayName || userEmail?.split('@')[0] || 'Novo Usuário',
                email: userEmail || '',
                role: isOwner ? 'admin' : 'staff',
                isActive: true,
                profile: isOwner ? 'ADMIN' : 'COLABORADOR',
                access: isOwner ? FULL_ACCESS : RESTRICTED_ACCESS,
                createdAt: serverTimestamp()
            };
            await setDoc(userDocRef, userData);
        }
        setState(prev => ({ ...prev, currentUser: userData }));
        setProfileReady(true);
        setAuthLoading(false);
    };
    initProfile();
  }, [firebaseUser]);

  useEffect(() => {
    if (!firebaseUser || !profileReady) return;
    const unsubscribers: (() => void)[] = [];
    const collections = [
        { name: "sales", setter: (data: any) => setState(p => ({...p, sales: data})) },
        { name: "campaigns", setter: (data: any) => setState(p => ({...p, campaigns: data})) },
        { name: "adSets", setter: (data: any) => setState(p => ({...p, adSets: data})) },
        { name: "creatives", setter: (data: any) => setState(p => ({...p, creatives: data})) },
        { name: "dailyMetrics", setter: (data: any) => setState(p => ({...p, dailyMetrics: data})) },
        { name: "goals", setter: (data: any) => setState(p => ({...p, goals: data})) },
        { name: "tasks", setter: (data: any) => setState(p => ({...p, tasks: data})) },
        { name: "transactions", setter: (data: any) => setState(p => ({...p, transactions: data})) },
        { name: "users", setter: (data: any) => setState(p => ({...p, users: data})) },
        { name: "cards", setter: (data: any) => setState(p => ({...p, cards: data})) },
        { name: "debtContracts", setter: (data: any) => setState(p => ({...p, debtContracts: data})) }
    ];
    collections.forEach(col => {
        unsubscribers.push(onSnapshot(collection(db, col.name), s => {
            col.setter(s.docs.map(d => ({...d.data(), id: d.id})));
        }, err => {
            console.error(`Sync error on ${col.name}:`, err.message);
        }));
    });
    return () => unsubscribers.forEach(u => u());
  }, [firebaseUser, profileReady]);

  const can = (key: keyof UserAccess): boolean => {
    const user = state.currentUser;
    if (!user) return false;
    if (user.profile === 'ADMIN') return true;
    return !!(user.access && user.access[key]);
  };

  const handleToggleTaskStatus = async (taskId: string, newStatus: TaskStatus) => {
    const task = state.tasks.find(t => t.id === taskId);
    if (!task) return;
    await updateDoc(doc(db, "tasks", taskId), { status: newStatus, updatedAt: serverTimestamp() });
    if (newStatus === 'Concluída' && task.isRecurring) {
        const nextDeadline = getNextOccurrenceDate(task.deadline, task.recurrence!);
        await addDoc(collection(db, "tasks"), { ...deepClean({ ...task, deadline: nextDeadline, status: 'A fazer' }), createdAt: serverTimestamp() });
    }
  };

  const contextValue: any = {
    ...state,
    logout: () => signOut(auth),
    can,
    profileReady,
    addCampaign: async (d: any) => (await addDoc(collection(db, "campaigns"), { ...deepClean(d), createdAt: serverTimestamp(), status: 'Ativa' })).id,
    updateCampaign: (c: any) => updateDoc(doc(db, "campaigns", c.id), { ...deepClean(c), updatedAt: serverTimestamp() }),
    deleteCampaign: (id: string) => deleteDoc(doc(db, "campaigns", id)),
    addAdSet: async (d: any) => (await addDoc(collection(db, "adSets"), { ...deepClean(d), createdAt: serverTimestamp(), status: 'Ativo' })).id,
    updateAdSet: (a: any) => updateDoc(doc(db, "adSets", a.id), { ...deepClean(a), updatedAt: serverTimestamp() }),
    deleteAdSet: (id: string) => deleteDoc(doc(db, "adSets", id)),
    addCreative: async (d: any) => (await addDoc(collection(db, "creatives"), { ...deepClean(d), createdAt: serverTimestamp() })).id,
    updateCreative: (c: any) => updateDoc(doc(db, "creatives", c.id), { ...deepClean(c), updatedAt: serverTimestamp() }),
    deleteCreative: (id: string) => deleteDoc(doc(db, "creatives", id)),
    addMetric: (m: any) => addDoc(collection(db, "dailyMetrics"), { ...deepClean(m), createdAt: serverTimestamp() }),
    updateMetric: (m: any) => updateDoc(doc(db, "dailyMetrics", m.id), { ...deepClean(m), updatedAt: serverTimestamp() }),
    deleteMetric: (id: string) => deleteDoc(doc(db, "dailyMetrics", id)),
    addSale: (s: any) => addDoc(collection(db, "sales"), { ...deepClean(s), createdAt: serverTimestamp() }),
    updateSale: (s: any) => updateDoc(doc(db, "sales", s.id), { ...deepClean(s), updatedAt: serverTimestamp() }),
    deleteSale: (id: string) => deleteDoc(doc(db, "sales", id)),
    addTask: (t: any) => addDoc(collection(db, "tasks"), { ...deepClean(t), createdAt: serverTimestamp() }),
    updateTask: (t: any) => updateDoc(doc(db, "tasks", t.id), { ...deepClean(t), updatedAt: serverTimestamp() }),
    deleteTask: (id: string) => deleteDoc(doc(db, "tasks", id)),
    toggleTaskStatus: handleToggleTaskStatus,
    addGoal: (g: any) => addDoc(collection(db, "goals"), { ...deepClean(g), createdAt: serverTimestamp() }),
    updateGoal: (g: any) => updateDoc(doc(db, "goals", g.id), { ...deepClean(g), updatedAt: serverTimestamp() }),
    deleteGoal: (id: string) => deleteDoc(doc(db, "goals", id)),
    addUser: (u: any) => addDoc(collection(db, "users"), { ...deepClean(u), createdAt: serverTimestamp() }),
    updateUser: (u: any) => updateDoc(doc(db, "users", u.id), { ...deepClean(u), updatedAt: serverTimestamp() }),
    deleteUser: (id: string) => deleteDoc(doc(db, "users", id)),
    addTransaction: async (t: any) => (await addDoc(collection(db, "transactions"), { ...deepClean(t), createdAt: serverTimestamp() })).id,
    updateTransaction: (t: any) => updateDoc(doc(db, "transactions", t.id), { ...deepClean(t), updatedAt: serverTimestamp() }),
    deleteTransaction: (id: string) => deleteDoc(doc(db, "transactions", id)),
    addCard: (d: any) => addDoc(collection(db, "cards"), { ...deepClean(d), createdAt: serverTimestamp() }),
    updateCard: (d: any) => updateDoc(doc(db, "cards", d.id), { ...deepClean(d), updatedAt: serverTimestamp() }),
    deleteCard: (id: string) => deleteDoc(doc(db, "cards", id)),
    addDebtContract: async (d: any) => (await addDoc(collection(db, "debtContracts"), { ...deepClean(d), createdAt: serverTimestamp() })).id,
    updateDebtContract: (d: any) => updateDoc(doc(db, "debtContracts", d.id), { ...deepClean(d), updatedAt: serverTimestamp() }),
    deleteDebtContract: (id: string) => deleteDoc(doc(db, "debtContracts", id)),
  };

  if (authLoading) return (
    <div className="h-screen w-screen flex items-center justify-center bg-slate-50">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-brand-600"></div>
    </div>
  );
  if (!firebaseUser) return <LoginPage auth={auth} />;

  return (
    <AppContext.Provider value={contextValue}>
      <HashRouter>
        <Layout>
          <Routes>
            <Route path="/" element={<ProtectedRoute module="dashboard"><Dashboard /></ProtectedRoute>} />
            <Route path="/vendas" element={<ProtectedRoute module="sales"><Sales /></ProtectedRoute>} />
            <Route path="/marketing" element={<ProtectedRoute module="marketing"><Marketing /></ProtectedRoute>} />
            <Route path="/financeiro" element={<ProtectedRoute module="finance"><Finance /></ProtectedRoute>} />
            <Route path="/equipe" element={<ProtectedRoute module="team"><Team /></ProtectedRoute>} />
            <Route path="/metas" element={<ProtectedRoute module="goals"><GoalsAndTasks /></ProtectedRoute>} />
            <Route path="*" element={<Navigate to="/" />} />
          </Routes>
        </Layout>
      </HashRouter>
    </AppContext.Provider>
  );
};

export default App;
