
import React, { useContext, useMemo } from 'react';
import { NavLink } from 'react-router-dom';
import { 
  LayoutDashboard, ShoppingBag, Megaphone, DollarSign, Users, Target, Menu, X, LogOut, Loader2
} from 'lucide-react';
import { AppContext } from '../App';
import { UserAccess } from '../types';

const SidebarItem: React.FC<{ to: string, icon: any, label: string, end?: boolean }> = ({ to, icon: Icon, label, end }) => (
  <NavLink
    to={to}
    end={end}
    className={({ isActive }) =>
      `flex items-center gap-3 px-4 py-3 rounded-xl transition-colors ${
        isActive 
          ? 'bg-brand-600 text-white shadow-md shadow-brand-500/20' 
          : 'text-slate-600 hover:bg-brand-50 hover:text-brand-600'
      }`
    }
  >
    <Icon size={18} />
    <span className="text-xs font-bold uppercase tracking-widest">{label}</span>
  </NavLink>
);

export const Layout: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { currentUser, logout, can, profileReady } = useContext(AppContext);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = React.useState(false);

  const menuItems = useMemo(() => [
      { to: "/", icon: LayoutDashboard, label: "Dashboard", module: 'dashboard' as keyof UserAccess, end: true },
      { to: "/vendas", icon: ShoppingBag, label: "Vendas", module: 'sales' as keyof UserAccess },
      { to: "/marketing", icon: Megaphone, label: "Marketing", module: 'marketing' as keyof UserAccess },
      { to: "/financeiro", icon: DollarSign, label: "Financeiro", module: 'finance' as keyof UserAccess },
      { to: "/equipe", icon: Users, label: "Equipe", module: 'team' as keyof UserAccess },
      { to: "/metas", icon: Target, label: "Metas & Tarefas", module: 'goals' as keyof UserAccess },
  ], []);

  const visibleMenuItems = useMemo(() => {
    if (!profileReady) return [];
    return menuItems.filter(item => can(item.module));
  }, [profileReady, currentUser, can, menuItems]);

  return (
    <div className="flex h-screen bg-slate-50 font-sans">
      {isMobileMenuOpen && <div className="fixed inset-0 bg-black/50 z-20 md:hidden backdrop-blur-sm" onClick={() => setIsMobileMenuOpen(false)} />}
      <aside className={`fixed md:relative z-30 w-64 h-full bg-white border-r border-slate-200 shadow-sm flex flex-col transition-transform duration-300 ${isMobileMenuOpen ? 'translate-x-0' : '-translate-x-full md:translate-x-0'}`}>
        <div className="p-6 border-b border-slate-100 flex justify-between items-center">
          <div>
            <h1 className="text-2xl font-bold text-brand-700">Ekoa<span className="text-slate-800">Manager</span></h1>
            <p className="text-xs text-slate-500 mt-1 uppercase font-bold tracking-widest">Operação</p>
          </div>
          <button onClick={() => setIsMobileMenuOpen(false)} className="md:hidden text-slate-500 hover:text-red-500"><X size={24} /></button>
        </div>
        <nav className="flex-1 overflow-y-auto p-4 space-y-1">
          {profileReady ? visibleMenuItems.map(item => (
            <SidebarItem key={item.to} to={item.to} icon={item.icon} label={item.label} end={item.end} />
          )) : (
            <div className="flex flex-col items-center justify-center py-12 text-slate-300 gap-3"><Loader2 className="animate-spin" size={24} /><span className="text-[10px] font-bold uppercase tracking-widest">Carregando menu...</span></div>
          )}
        </nav>
        <div className="p-4 border-t border-slate-100 bg-slate-50/50">
          <div className="flex items-center gap-3 p-2 bg-white rounded-xl border border-slate-100 shadow-sm overflow-hidden">
            <div className={`flex-shrink-0 w-10 h-10 rounded-full flex items-center justify-center text-white font-bold text-lg ${profileReady && currentUser?.role?.toLowerCase() === 'admin' ? 'bg-brand-600' : 'bg-slate-400'}`}>
              {profileReady ? (currentUser?.name?.charAt(0).toUpperCase() || 'U') : '...'}
            </div>
            <div className="flex-1 overflow-hidden">
              <p className="text-sm font-bold text-slate-800 truncate">{profileReady ? (currentUser?.name || 'Usuário') : 'Autenticando...'}</p>
              <span className={`text-[10px] uppercase font-bold px-1.5 py-0.5 rounded truncate ${currentUser?.role?.toLowerCase() === 'admin' ? 'bg-purple-100 text-purple-700' : 'bg-slate-100 text-slate-500'}`}>{profileReady ? (currentUser?.role || 'staff') : 'Aguardando'}</span>
            </div>
          </div>
          <button onClick={logout} className="w-full mt-4 flex items-center justify-center gap-2 px-4 py-2.5 bg-white border border-red-200 text-red-600 text-xs font-bold rounded-xl hover:bg-red-50"><LogOut size={14} /> SAIR</button>
        </div>
      </aside>
      <main className="flex-1 flex flex-col h-full overflow-hidden">
        <header className="md:hidden bg-white border-b border-slate-200 p-4 flex justify-between items-center"><h1 className="font-bold text-brand-700">EkoaManager</h1><button onClick={() => setIsMobileMenuOpen(true)} className="text-slate-600 p-2 hover:bg-slate-100 rounded-lg"><Menu size={24} /></button></header>
        <div className="flex-1 overflow-auto p-4 md:p-8">{children}</div>
      </main>
    </div>
  );
};
