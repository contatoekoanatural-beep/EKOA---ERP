
import React, { useContext, useMemo, useState, useEffect } from 'react';
import { AppContext } from '../App';
import { formatCurrency, getCurrentLocalDate, getLast30DaysDate } from '../constants';
import { 
  XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, LineChart, Line
} from 'recharts';
import { 
  TrendingUp, CheckCircle, DollarSign, Megaphone, Calendar, XCircle, Trophy, 
  Globe, BarChart3, PieChart, ChevronDown, UserCheck, CalendarClock, Tag, Wallet 
} from 'lucide-react';

const StatCard = ({ title, value, subtext, icon: Icon, colorClass }: any) => (
  <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100 flex flex-col justify-between h-full">
    <div className="flex items-start justify-between">
      <div>
        <p className="text-[10px] font-black uppercase tracking-widest text-slate-400">{title}</p>
        <h3 className="text-2xl font-black text-slate-800 mt-1">{value}</h3>
        {subtext && <p className="text-[10px] font-bold text-slate-400 mt-1">{subtext}</p>}
      </div>
      <div className={`p-3 rounded-xl ${colorClass}`}>
        <Icon size={22} />
      </div>
    </div>
  </div>
);

type PeriodOption = 'hoje' | '7d_passado' | '7d_futuro' | '30d_passado' | '30d_futuro' | 'este_mes' | 'mes_passado' | 'personalizado' | 'tudo';

export const Dashboard = () => {
  const { sales, dailyMetrics, creatives } = useContext(AppContext);
  
  const [selectedPeriod, setSelectedPeriod] = useState<PeriodOption>('30d_passado');
  const [dateFrom, setDateFrom] = useState<string>(getLast30DaysDate());
  const [dateTo, setDateTo] = useState<string>(getCurrentLocalDate());

  // Lógica para atualizar as datas baseado no período selecionado
  useEffect(() => {
    const today = new Date();
    const formatDate = (d: Date) => d.toISOString().split('T')[0];

    switch (selectedPeriod) {
      case 'hoje':
        setDateFrom(formatDate(today));
        setDateTo(formatDate(today));
        break;
      case '7d_passado': {
        const start = new Date();
        start.setDate(today.getDate() - 6);
        setDateFrom(formatDate(start));
        setDateTo(formatDate(today));
        break;
      }
      case '7d_futuro': {
        const end = new Date();
        end.setDate(today.getDate() + 6);
        setDateFrom(formatDate(today));
        setDateTo(formatDate(end));
        break;
      }
      case '30d_passado': {
        const start = new Date();
        start.setDate(today.getDate() - 29);
        setDateFrom(formatDate(start));
        setDateTo(formatDate(today));
        break;
      }
      case '30d_futuro': {
        const end = new Date();
        end.setDate(today.getDate() + 29);
        setDateFrom(formatDate(today));
        setDateTo(formatDate(end));
        break;
      }
      case 'este_mes': {
        const start = new Date(today.getFullYear(), today.getMonth(), 1);
        const end = new Date(today.getFullYear(), today.getMonth() + 1, 0);
        setDateFrom(formatDate(start));
        setDateTo(formatDate(end));
        break;
      }
      case 'mes_passado': {
        const start = new Date(today.getFullYear(), today.getMonth() - 1, 1);
        const end = new Date(today.getFullYear(), today.getMonth(), 0);
        setDateFrom(formatDate(start));
        setDateTo(formatDate(end));
        break;
      }
      case 'tudo':
        setDateFrom('');
        setDateTo('');
        break;
      case 'personalizado':
        // Mantém as datas atuais para o usuário editar
        break;
    }
  }, [selectedPeriod]);

  const isFiltered = !!(dateFrom || dateTo);

  const isWithinRange = (dateStr?: string | null) => {
      if (!dateFrom && !dateTo) return true;
      if (!dateStr) return false;
      const d = dateStr.split('T')[0];
      const start = dateFrom || '0000-01-01';
      const end = dateTo || '9999-12-31';
      return d >= start && d <= end;
  };

  const kpis = useMemo(() => {
    const revenueRealized = sales
      .filter(s => s.status === 'ENTREGUE' && isWithinRange(s.deliveryDate))
      .reduce((acc, curr) => acc + curr.value, 0);
    
    const filteredMetrics = dailyMetrics.filter(m => isWithinRange(m.date));
    const totalInvestment = filteredMetrics.reduce((acc, curr) => acc + curr.investment, 0);
    const roas = totalInvestment > 0 ? revenueRealized / totalInvestment : 0;
    const totalProfit = revenueRealized - totalInvestment;

    const deliveredCount = sales.filter(s => s.status === 'ENTREGUE' && isWithinRange(s.deliveryDate)).length;
    const frustratedCount = sales.filter(s => s.status === 'FRUSTRADO' && isWithinRange(s.scheduledDate)).length;
    const scheduledCount = sales.filter(s => s.status === 'AGENDADO' && isWithinRange(s.scheduledDate)).length;
    const rescheduledCount = sales.filter(s => s.status === 'REAGENDADO' && isWithinRange(s.scheduledDate)).length;
    const scheduledTotal = scheduledCount + rescheduledCount;
    
    const totalResolved = deliveredCount + frustratedCount;

    return {
      revenueRealized, totalInvestment, roas, totalProfit,
      deliveryRate: totalResolved > 0 ? (deliveredCount / totalResolved) * 100 : 0,
      deliveredCount, frustratedCount, scheduledCount, rescheduledCount,
      custoPorVenda: deliveredCount > 0 ? totalInvestment / deliveredCount : 0,
      custoPorAgendamento: scheduledTotal > 0 ? totalInvestment / scheduledTotal : 0,
      ticketMedio: deliveredCount > 0 ? revenueRealized / deliveredCount : 0,
      lucroPorVenda: deliveredCount > 0 ? totalProfit / deliveredCount : 0,
      filteredMetrics
    };
  }, [sales, dailyMetrics, dateFrom, dateTo]);

  const chartData = useMemo(() => {
    // Se não houver dataDe ou dataAte (Ex: "Tudo"), usamos o comportamento antigo de agrupar apenas o que existe
    if (!dateFrom || !dateTo) {
      const dataMap: Record<string, any> = {};
      sales.forEach(s => {
        let date = '';
        if (s.status === 'ENTREGUE') date = s.deliveryDate || '';
        else if (s.status === 'FRUSTRADO') date = s.scheduledDate || '';
        
        if (date) {
            if (!dataMap[date]) dataMap[date] = { date, Entregues: 0, Frustrados: 0 };
            if (s.status === 'ENTREGUE') dataMap[date].Entregues += 1;
            else if (s.status === 'FRUSTRADO') dataMap[date].Frustrados += 1;
        }
      });
      return Object.values(dataMap)
        .sort((a, b) => a.date.localeCompare(b.date))
        .map((d: any) => ({ ...d, date: d.date.split('-').reverse().slice(0, 2).join('/') }));
    }

    // Caso contrário, geramos TODOS os dias do intervalo para preencher lacunas
    const start = new Date(dateFrom + 'T12:00:00');
    const end = new Date(dateTo + 'T12:00:00');
    const diffDays = Math.ceil((end.getTime() - start.getTime()) / (1000 * 60 * 60 * 24));

    // Se o intervalo for muito longo (>90 dias), voltamos ao comportamento de agrupar só existentes para não poluir
    if (diffDays > 90) {
        const dataMap: Record<string, any> = {};
        sales.forEach(s => {
          let date = '';
          if (s.status === 'ENTREGUE') date = s.deliveryDate || '';
          else if (s.status === 'FRUSTRADO') date = s.scheduledDate || '';
          
          if (date && date >= dateFrom && date <= dateTo) {
              if (!dataMap[date]) dataMap[date] = { date, Entregues: 0, Frustrados: 0 };
              if (s.status === 'ENTREGUE') dataMap[date].Entregues += 1;
              else if (s.status === 'FRUSTRADO') dataMap[date].Frustrados += 1;
          }
        });
        return Object.values(dataMap)
          .sort((a, b) => a.date.localeCompare(b.date))
          .map((d: any) => ({ ...d, date: d.date.split('-').reverse().slice(0, 2).join('/') }));
    }

    // Geração de escala completa para intervalos normais
    const data: any[] = [];
    const counts: Record<string, {e: number, f: number}> = {};

    sales.forEach(s => {
       let date = '';
       if (s.status === 'ENTREGUE') date = s.deliveryDate || '';
       else if (s.status === 'FRUSTRADO') date = s.scheduledDate || '';
       if (date && date >= dateFrom && date <= dateTo) {
           if (!counts[date]) counts[date] = { e: 0, f: 0 };
           if (s.status === 'ENTREGUE') counts[date].e += 1;
           else if (s.status === 'FRUSTRADO') counts[date].f += 1;
       }
    });

    for (let d = new Date(start); d <= end; d.setDate(d.getDate() + 1)) {
        const dateStr = d.toISOString().split('T')[0];
        data.push({
            date: dateStr.split('-').reverse().slice(0, 2).join('/'),
            Entregues: counts[dateStr]?.e || 0,
            Frustrados: counts[dateStr]?.f || 0
        });
    }

    return data;
  }, [sales, dateFrom, dateTo]);

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row justify-between items-center gap-4">
        <div>
            <h2 className="text-2xl font-black text-slate-800 tracking-tight">Dashboard Operacional</h2>
            <div className="flex items-center gap-2 mt-1">
                {isFiltered ? (
                    <span className="flex items-center gap-1 text-[9px] font-black uppercase tracking-wider text-brand-600 bg-brand-50 px-2 py-0.5 rounded-full border border-brand-100">
                        Período Ativo
                    </span>
                ) : (
                    <span className="flex items-center gap-1 text-[9px] font-black uppercase tracking-wider text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded-full border border-emerald-100">
                        <Globe size={10} /> Resultado Acumulado
                    </span>
                )}
            </div>
        </div>
        
        <div className="flex flex-wrap items-center gap-3">
            <div className="relative">
                <select 
                    value={selectedPeriod}
                    onChange={(e) => setSelectedPeriod(e.target.value as PeriodOption)}
                    className="appearance-none bg-white border border-slate-200 rounded-xl pl-4 pr-10 py-2.5 text-xs font-black uppercase tracking-widest text-slate-700 shadow-sm focus:outline-none focus:ring-2 focus:ring-brand-500 cursor-pointer"
                >
                    <option value="hoje">Hoje</option>
                    <option value="7d_passado">Últimos 7 dias</option>
                    <option value="7d_futuro">Próximos 7 dias</option>
                    <option value="30d_passado">Últimos 30 dias</option>
                    <option value="30d_futuro">Próximos 30 dias</option>
                    <option value="este_mes">Este mês</option>
                    <option value="mes_passado">Mês passado</option>
                    <option value="tudo">Ver Tudo</option>
                    <option value="personalizado">Personalizado</option>
                </select>
                <div className="absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none text-slate-400">
                    <ChevronDown size={14} />
                </div>
            </div>

            {selectedPeriod === 'personalizado' && (
                <div className="flex items-center gap-2 bg-white border border-slate-200 rounded-xl p-1.5 shadow-sm animate-in fade-in slide-in-from-right-2 duration-200">
                    <Calendar size={18} className="text-slate-400 ml-2" />
                    <input 
                        type="date" 
                        className="text-xs font-bold border-none focus:ring-0 text-slate-700 bg-transparent outline-none cursor-pointer"
                        value={dateFrom}
                        onChange={(e) => setDateFrom(e.target.value)}
                    />
                    <span className="text-slate-300 text-[10px] font-bold">até</span>
                    <input 
                        type="date" 
                        className="text-xs font-bold border-none focus:ring-0 text-slate-700 bg-transparent outline-none cursor-pointer"
                        value={dateTo}
                        onChange={(e) => setDateTo(e.target.value)}
                    />
                </div>
            )}
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-4">
        <StatCard title="Faturamento" value={formatCurrency(kpis.revenueRealized)} icon={DollarSign} colorClass="bg-emerald-50 text-emerald-600" />
        <StatCard title="Investimento Ads" value={formatCurrency(kpis.totalInvestment)} subtext={`ROAS: ${kpis.roas.toFixed(2)}`} icon={Megaphone} colorClass="bg-orange-50 text-orange-600" />
        <StatCard title="Lucro Bruto" value={formatCurrency(kpis.totalProfit)} subtext="Faturamento - Ads" icon={BarChart3} colorClass="bg-brand-50 text-brand-600" />
        <StatCard title="ROAS Geral" value={`${kpis.roas.toFixed(2)}x`} icon={TrendingUp} colorClass="bg-blue-50 text-blue-600" />
        <StatCard title="Taxa Entrega" value={`${kpis.deliveryRate.toFixed(1)}%`} icon={CheckCircle} colorClass="bg-purple-50 text-purple-600" />
        
        <StatCard title="Custo por Venda" value={formatCurrency(kpis.custoPorVenda)} subtext="CAC (Ads / Entregues)" icon={UserCheck} colorClass="bg-emerald-50 text-emerald-600" />
        <StatCard title="Custo por Agendamento" value={formatCurrency(kpis.custoPorAgendamento)} subtext="Ads / Agendados" icon={CalendarClock} colorClass="bg-amber-50 text-amber-600" />
        <StatCard title="Ticket Médio" value={formatCurrency(kpis.ticketMedio)} subtext="Média por venda entregue" icon={Tag} colorClass="bg-sky-50 text-sky-600" />
        <StatCard title="Lucro por Venda" value={formatCurrency(kpis.lucroPorVenda)} subtext="Média de lucro líquido" icon={Wallet} colorClass="bg-indigo-50 text-indigo-600" />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white p-6 rounded-3xl shadow-sm border border-slate-100">
          <div className="flex items-center justify-between mb-6">
              <h3 className="text-lg font-black text-slate-800 flex items-center gap-2"><PieChart className="text-brand-600" /> Funil de Vendas</h3>
              <span className="text-[10px] font-black uppercase text-slate-400">Dados do Período</span>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div className="p-5 bg-blue-50 rounded-2xl border border-blue-100/50">
              <span className="block text-3xl font-black text-blue-700">{kpis.scheduledCount}</span>
              <span className="text-[10px] font-black uppercase text-blue-600 tracking-widest">Agendados</span>
            </div>
            <div className="p-5 bg-amber-50 rounded-2xl border border-amber-100/50">
              <span className="block text-3xl font-black text-amber-700">{kpis.rescheduledCount}</span>
              <span className="text-[10px] font-black uppercase text-amber-600 tracking-widest">Reagendados</span>
            </div>
            <div className="p-5 bg-emerald-50 rounded-2xl border border-emerald-100/50">
              <span className="block text-3xl font-black text-emerald-700">{kpis.deliveredCount}</span>
              <span className="text-[10px] font-black uppercase text-emerald-600 tracking-widest">Entregues</span>
            </div>
            <div className="p-5 bg-red-50 rounded-2xl border border-red-100/50">
              <span className="block text-3xl font-black text-red-700">{kpis.frustratedCount}</span>
              <span className="text-[10px] font-black uppercase text-red-600 tracking-widest">Frustrados</span>
            </div>
          </div>
        </div>

        <div className="bg-white p-6 rounded-3xl shadow-sm border border-slate-100">
          <div className="flex items-center justify-between mb-6">
              <h3 className="text-lg font-black text-slate-800 flex items-center gap-2"><TrendingUp className="text-emerald-600" /> Desempenho Diário</h3>
          </div>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={chartData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" vertical={false} />
                <XAxis dataKey="date" tick={{fontSize: 10, fontWeight: 'bold'}} axisLine={false} tickLine={false} />
                <YAxis tick={{fontSize: 10, fontWeight: 'bold'}} axisLine={false} tickLine={false} />
                <Tooltip contentStyle={{borderRadius: '16px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)'}} />
                <Legend iconType="circle" wrapperStyle={{paddingTop: '20px', fontSize: '10px', fontWeight: 'bold', textTransform: 'uppercase'}} />
                <Line type="monotone" dataKey="Entregues" stroke="#10b981" strokeWidth={4} dot={{ r: 4 }} activeDot={{ r: 6 }} />
                <Line type="monotone" dataKey="Frustrados" stroke="#ef4444" strokeWidth={4} dot={{ r: 4 }} activeDot={{ r: 6 }} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>
    </div>
  );
};
