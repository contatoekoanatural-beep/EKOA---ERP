
import React, { useContext, useState, useMemo, useEffect } from 'react';
import { AppContext } from '../App';
import { formatCurrency, getCurrentLocalDate, formatDate } from '../constants';
import { 
  Plus, Edit2, Trash2, X, Calculator, ArrowUpCircle, ArrowDownCircle, 
  TrendingUp, CreditCard, Landmark, ReceiptText, ArrowLeft, Clock, ArrowRight, ChevronDown, Check, ShoppingBag, AlertTriangle, Eye, Calendar, CheckCircle2, Eraser, Filter, ShieldAlert
} from 'lucide-react';
import { Transaction, CardConfig, DebtContract, TransactionNature, TransactionStatus, PaymentMethod } from '../types';

const StatCard = ({ title, value, subtext, icon: Icon, colorClass, highlight = false }: any) => (
  <div className={`p-6 rounded-3xl shadow-sm border ${highlight ? 'bg-brand-600 border-brand-700 text-white' : 'bg-white border-slate-100'} flex flex-col justify-between h-full transition-all hover:shadow-md`}>
    <div className="flex items-start justify-between">
      <div>
        <p className={`text-[10px] font-black uppercase tracking-widest ${highlight ? 'text-brand-100' : 'text-slate-400'}`}>{title}</p>
        <h3 className="text-2xl font-black mt-1">{value}</h3>
        {subtext && <p className={`text-[10px] font-bold mt-1 ${highlight ? 'text-brand-200' : 'text-slate-400'}`}>{subtext}</p>}
      </div>
      <div className={`p-3 rounded-2xl ${highlight ? 'bg-white/20 text-white' : colorClass}`}>
        <Icon size={24} />
      </div>
    </div>
  </div>
);

export const Finance = () => {
  const { 
    transactions, cards, debtContracts,
    addTransaction, updateTransaction, deleteTransaction,
    addCard, updateCard, deleteCard,
    addDebtContract, updateDebtContract, deleteDebtContract
  } = useContext(AppContext);

  const [activeTab, setActiveTab] = useState<'OVERVIEW' | 'FLOW' | 'RECURRENCES' | 'CARDS' | 'DEBTS' | 'CARD_DETAILS'>('OVERVIEW');
  const [filterMonth, setFilterMonth] = useState(new Date().toISOString().slice(0, 7));
  const [showAllCardPending, setShowAllCardPending] = useState(false);

  const [isModalOpen, setIsModalOpen] = useState(false);
  const [modalType, setModalType] = useState<'TRANSACTION' | 'CARD' | 'DEBT' | 'DELETE_CONFIRM' | null>(null);
  const [editingItem, setEditingItem] = useState<any>(null);
  const [selectedCardId, setSelectedCardId] = useState<string | null>(null);
  const [itemToDelete, setItemToDelete] = useState<Transaction | null>(null);

  const [debtCalc, setDebtCalc] = useState({ total: 0, part: 0, count: 1 });

  // --- MEMOS DE DADOS ---

  const currentMonthTransactions = useMemo(() => {
    return transactions.filter(t => t.referenceMonth === filterMonth);
  }, [transactions, filterMonth]);

  const stats = useMemo(() => {
    const incomings = currentMonthTransactions.filter(t => t.type === 'income').reduce((acc, t) => acc + t.amount, 0);
    const outgoings = currentMonthTransactions.filter(t => t.type === 'expense').reduce((acc, t) => acc + t.amount, 0);
    const totalOpenDebt = debtContracts.filter(d => d.status === 'Ativo').reduce((acc, d) => acc + d.totalDebtRemaining, 0);
    return { 
      incomings, 
      outgoings, 
      balance: incomings - outgoings, 
      totalOpenDebt, 
      monthlyDebtInstallments: currentMonthTransactions.filter(t => t.nature === 'parcela').reduce((acc, t) => acc + t.amount, 0) 
    };
  }, [currentMonthTransactions, debtContracts]);

  const flowEntries = useMemo(() => {
    const nonCardTx = currentMonthTransactions.filter(t => t.method !== 'cartao');
    const cardTx = currentMonthTransactions.filter(t => t.method === 'cartao');
    const cardGroups: Record<string, any> = {};

    cardTx.forEach(t => {
      const cId = t.cardId || 'unknown';
      if (!cardGroups[cId]) {
        const cardName = cards.find(c => c.id === cId)?.name || 'Cartão';
        cardGroups[cId] = {
          id: `group-${cId}`,
          description: `Fatura ${cardName}`,
          amount: 0,
          method: 'cartao',
          status: 'pago',
          type: 'expense',
          date: t.date,
          referenceMonth: t.referenceMonth,
          isGroup: true
        };
      }
      cardGroups[cId].amount += t.amount;
      if (t.status === 'previsto') cardGroups[cId].status = 'previsto';
    });

    return [...nonCardTx, ...Object.values(cardGroups)].sort((a, b) => (a.date || '').localeCompare(b.date || ''));
  }, [currentMonthTransactions, cards]);

  // Inteligência de Recorrências: Identifica series fixas mesmo que não lançadas no mês
  const recurrenceMasterList = useMemo(() => {
    const allRecurrences = transactions.filter(t => t.nature === 'recorrente');
    const uniqueSeries: Record<string, any> = {};
    
    allRecurrences.forEach(t => {
      if (!uniqueSeries[t.description]) {
        uniqueSeries[t.description] = { ...t, currentMonthStatus: 'Não Lançado' };
      }
    });

    // Verifica status no mês atual selecionado
    Object.keys(uniqueSeries).forEach(desc => {
      const thisMonth = currentMonthTransactions.find(t => t.description === desc && t.nature === 'recorrente');
      if (thisMonth) {
        uniqueSeries[desc].currentMonthStatus = thisMonth.status;
        uniqueSeries[desc].amount = thisMonth.amount;
        uniqueSeries[desc].id = thisMonth.id; // Usa o ID do mês para edição
      }
    });

    return Object.values(uniqueSeries);
  }, [transactions, currentMonthTransactions]);

  const selectedCard = useMemo(() => cards.find(c => c.id === selectedCardId), [cards, selectedCardId]);

  // Lógica de cálculo de limite por cartão (Corrigida para evitar duplicidade)
  const getCardUsage = (cardId: string) => {
    const activeContracts = debtContracts.filter(d => d.cardId === cardId && d.status === 'Ativo');
    const contractDebt = activeContracts.reduce((acc, d) => acc + d.totalDebtRemaining, 0);
    const contractIds = new Set(activeContracts.map(d => d.id));

    // Pega TUDO que é previsto e gasta limite (independente do mês)
    const otherPending = transactions.filter(t => 
      t.cardId === cardId && 
      t.status === 'previsto' && 
      t.type === 'expense' &&
      (!t.contractId || !contractIds.has(t.contractId))
    ).reduce((acc, t) => acc + t.amount, 0);

    return contractDebt + otherPending;
  };

  const cardTransactions = useMemo(() => {
    if (!selectedCardId) return [];
    return transactions
      .filter(t => {
        const isThisCard = t.cardId === selectedCardId;
        if (!isThisCard) return false;
        // Se showAll estiver ativo, mostramos TUDO que está com status previsto ocupando o limite
        if (showAllCardPending) return t.status === 'previsto' && t.type === 'expense';
        // Caso contrário, apenas transações do mês selecionado
        return t.referenceMonth === filterMonth;
      })
      .sort((a, b) => a.date.localeCompare(b.date));
  }, [transactions, selectedCardId, filterMonth, showAllCardPending]);

  // --- HANDLERS ---

  const handleOpenTransaction = (t?: any) => {
    setModalType('TRANSACTION');
    const item = t || { 
      type: 'expense', nature: 'avulso', status: 'previsto', method: 'pix', 
      date: getCurrentLocalDate(), referenceMonth: filterMonth, amount: 0, 
      description: '', category: 'Geral'
    };
    setEditingItem(item);
    setDebtCalc({ 
      total: item.amount * (item.installmentsInfo?.total || 1) || 0, 
      part: item.amount || 0, 
      count: item.installmentsInfo?.total || 1 
    });
    setIsModalOpen(true);
  };

  const handleQuickCleanup = async () => {
    if (!selectedCardId) return;
    const overdue = transactions.filter(t => 
      t.cardId === selectedCardId && 
      t.status === 'previsto' && 
      t.referenceMonth < filterMonth
    );

    if (overdue.length === 0) {
      alert("Nenhuma pendência de meses passados encontrada.");
      return;
    }

    if (window.confirm(`Deseja marcar ${overdue.length} lançamentos de meses ANTERIORES como PAGOS? Isso liberará o limite usado por itens esquecidos.`)) {
      for (const t of overdue) {
        await updateTransaction({ ...t, status: 'pago' });
      }
    }
  };

  const confirmDelete = async (mode: 'ONLY_THIS' | 'ALL_RELATED') => {
    if (!itemToDelete) return;
    if (mode === 'ONLY_THIS') {
      await deleteTransaction(itemToDelete.id);
    } else {
      const rootId = itemToDelete.recurrenceId || itemToDelete.contractId || itemToDelete.id;
      const related = transactions.filter(t => t.recurrenceId === rootId || t.contractId === rootId || t.id === rootId);
      for (const t of related) await deleteTransaction(t.id);
    }
    setIsModalOpen(false);
    setItemToDelete(null);
  };

  const handleSaveTransaction = async (e: React.FormEvent) => {
    e.preventDefault();
    const isNew = !editingItem.id;
    const isMulti = (editingItem.method === 'cartao' || editingItem.nature === 'parcela') && debtCalc.count > 1;

    if (!isNew) {
      await updateTransaction(editingItem);
    } else {
      const firstTx = {
          ...editingItem,
          amount: isMulti ? debtCalc.part : editingItem.amount,
          installmentsInfo: isMulti ? { current: 1, total: Math.round(debtCalc.count) } : undefined
      };
      const mainId = await addTransaction(firstTx);
      
      if (isMulti) {
        const totalCount = Math.round(debtCalc.count);
        for (let i = 1; i < totalCount; i++) {
            const d = new Date(editingItem.date + 'T12:00:00'); d.setMonth(d.getMonth() + i);
            const ds = d.toISOString().split('T')[0];
            await addTransaction({
                ...editingItem,
                description: `${editingItem.description} (${i+1}/${totalCount})`,
                amount: debtCalc.part,
                date: ds, referenceMonth: ds.slice(0, 7),
                installmentsInfo: { current: i+1, total: totalCount },
                recurrenceId: mainId
            });
        }
        await updateTransaction({ ...firstTx, id: mainId, description: `${firstTx.description} (1/${totalCount})` });
      }
    }
    setIsModalOpen(false);
  };

  return (
    <div className="space-y-8 max-w-[1400px] mx-auto pb-12">
      <div className="flex flex-col lg:flex-row justify-between items-start lg:items-end gap-6">
        <div>
          <h2 className="text-3xl font-black text-slate-800 tracking-tight">Gestão Financeira</h2>
          <div className="flex items-center gap-4 mt-1">
            <div className="flex bg-white rounded-xl p-1 shadow-sm border border-slate-100 overflow-x-auto max-w-[100vw]">
               {['OVERVIEW', 'FLOW', 'RECURRENCES', 'CARDS', 'DEBTS'].map((tab) => (
                 <button key={tab} onClick={() => setActiveTab(tab as any)} className={`px-4 py-2 rounded-lg text-[10px] font-black uppercase whitespace-nowrap transition-all ${activeTab === tab ? 'bg-brand-600 text-white shadow-md' : 'text-slate-400 hover:bg-slate-50'}`}>
                   {tab === 'OVERVIEW' ? 'Visão Geral' : tab === 'FLOW' ? 'Fluxo' : tab === 'RECURRENCES' ? 'Recorrências' : tab === 'CARDS' ? 'Cartões' : 'Dívidas'}
                 </button>
               ))}
            </div>
          </div>
        </div>
        <div className="flex gap-3 w-full lg:w-auto">
          <input type="month" className="bg-white border border-slate-200 rounded-xl px-4 py-2 text-sm font-black outline-none shadow-sm" value={filterMonth} onChange={e => setFilterMonth(e.target.value)} />
          <button onClick={() => handleOpenTransaction()} className="bg-brand-600 text-white px-6 py-3 rounded-2xl font-black text-[10px] uppercase shadow-xl shadow-brand-500/20 hover:bg-brand-700 flex items-center gap-2 transition-all"><Plus size={18} /> Novo Lançamento</button>
        </div>
      </div>

      {activeTab === 'OVERVIEW' && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-5 animate-in fade-in duration-300">
          <StatCard title="Saídas Previstas" value={formatCurrency(stats.outgoings)} icon={ArrowDownCircle} colorClass="bg-red-50 text-red-600" />
          <StatCard title="Entradas Previstas" value={formatCurrency(stats.incomings)} icon={ArrowUpCircle} colorClass="bg-emerald-50 text-emerald-600" />
          <StatCard title="Saldo Projetado" value={formatCurrency(stats.balance)} highlight={true} icon={Calculator} />
          <StatCard title="Dívida Total Aberta" value={formatCurrency(stats.totalOpenDebt)} subtext={`Parcela mensal: ${formatCurrency(stats.monthlyDebtInstallments)}`} icon={Landmark} colorClass="bg-indigo-50 text-indigo-600" />
        </div>
      )}

      {activeTab === 'FLOW' && (
        <div className="bg-white rounded-[40px] border border-slate-100 shadow-sm overflow-hidden animate-in slide-in-from-bottom-2 duration-300">
          <div className="p-6 border-b border-slate-50 bg-slate-50/50 flex justify-between items-center"><h3 className="font-black text-slate-800 uppercase text-[11px] tracking-widest">Fluxo Mensal</h3></div>
          <div className="overflow-x-auto">
            <table className="w-full text-left">
              <thead><tr className="text-[10px] font-black uppercase text-slate-400 border-b"><th className="p-6">Data</th><th className="p-6">Descrição</th><th className="p-6 text-right">Valor</th><th className="p-6 text-center">Status</th><th className="p-6 text-center">Ações</th></tr></thead>
              <tbody className="divide-y">
                {flowEntries.map(entry => (
                  <tr key={entry.id} className="hover:bg-slate-50 group">
                    <td className="p-6 text-xs font-black text-slate-700">{formatDate(entry.date)}</td>
                    <td className="p-6 flex items-center gap-3"><div className={`p-2 rounded-lg ${entry.type === 'income' ? 'bg-emerald-50 text-emerald-600' : 'bg-red-50 text-red-600'}`}>{entry.type === 'income' ? <ArrowUpCircle size={14}/> : <ArrowDownCircle size={14}/>}</div><span className="font-black text-slate-800 text-sm">{entry.description}</span></td>
                    <td className="p-6 text-right font-black text-slate-800">{formatCurrency(entry.amount)}</td>
                    <td className="p-6 text-center"><span className={`text-[8px] font-black uppercase px-3 py-1 rounded-full border ${entry.status === 'pago' ? 'bg-emerald-50 text-emerald-600 border-emerald-100' : 'bg-amber-50 text-amber-600 border-amber-100'}`}>{entry.status}</span></td>
                    <td className="p-6 text-center"><div className="flex justify-center gap-2 opacity-0 group-hover:opacity-100 transition-opacity"><button onClick={() => handleOpenTransaction(entry)} className="p-2 text-slate-300 hover:text-brand-600"><Edit2 size={16}/></button><button onClick={() => {setItemToDelete(entry); setModalType('DELETE_CONFIRM'); setIsModalOpen(true);}} className="p-2 text-slate-300 hover:text-red-500"><Trash2 size={16}/></button></div></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {activeTab === 'RECURRENCES' && (
        <div className="bg-white rounded-[40px] border border-slate-100 shadow-sm overflow-hidden animate-in slide-in-from-bottom-2 duration-300">
          <div className="p-6 border-b border-slate-50 bg-slate-50/50 flex justify-between items-center"><h3 className="font-black text-slate-800 uppercase text-[11px] tracking-widest">Contas Fixas / Recorrências</h3><p className="text-[10px] font-black text-slate-400 uppercase">Referência: {filterMonth}</p></div>
          <div className="overflow-x-auto">
            <table className="w-full text-left">
              <thead><tr className="text-[10px] font-black uppercase text-slate-400 border-b"><th className="p-6">Conta Fixa</th><th className="p-6 text-right">Valor Padrão</th><th className="p-6 text-center">Status no Mês</th><th className="p-6 text-center">Ações</th></tr></thead>
              <tbody className="divide-y">
                {recurrenceMasterList.map(item => (
                  <tr key={item.description} className="hover:bg-slate-50">
                    <td className="p-6 font-black text-slate-800 text-sm flex items-center gap-3"><Clock size={14} className="text-brand-500"/> {item.description}</td>
                    <td className="p-6 text-right font-black text-slate-800">{formatCurrency(item.amount)}</td>
                    <td className="p-6 text-center">
                        <span className={`text-[8px] font-black uppercase px-3 py-1 rounded-full border ${
                            item.currentMonthStatus === 'pago' ? 'bg-emerald-50 text-emerald-600 border-emerald-100' : 
                            item.currentMonthStatus === 'previsto' ? 'bg-amber-50 text-amber-600 border-amber-100' :
                            'bg-slate-50 text-slate-400 border-slate-200'
                        }`}>{item.currentMonthStatus}</span>
                    </td>
                    <td className="p-6 text-center">
                        {item.currentMonthStatus !== 'Não Lançado' ? (
                            <button onClick={() => handleOpenTransaction(item)} className="p-2 text-slate-300 hover:text-brand-600"><Edit2 size={16}/></button>
                        ) : (
                            <button onClick={() => handleOpenTransaction({ ...item, id: null, referenceMonth: filterMonth })} className="text-[9px] font-black uppercase text-brand-600 hover:underline">Lançar no Mês</button>
                        )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {activeTab === 'CARDS' && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 animate-in slide-in-from-bottom-2 duration-300">
           {cards.map(card => {
             const used = getCardUsage(card.id);
             const pct = card.limit > 0 ? (used / card.limit) * 100 : 0;
             const isOver = used > card.limit;

             return (
               <div key={card.id} onClick={() => { setSelectedCardId(card.id); setActiveTab('CARD_DETAILS'); }} className="bg-white p-6 rounded-[32px] border border-slate-100 shadow-sm relative group cursor-pointer hover:border-brand-300 transition-all active:scale-[0.98]">
                  <div className="flex justify-between items-start mb-4">
                     <div className="flex items-center gap-3">
                        <div className={`p-3 rounded-2xl transition-colors ${isOver ? 'bg-red-50 text-red-600' : 'bg-brand-50 text-brand-600'}`}><CreditCard size={20}/></div>
                        <div><p className="font-black text-slate-800">{card.name}</p><p className="text-[9px] font-black text-slate-400 uppercase tracking-tighter">Fecha: {card.closingDay} • Vence: {card.dueDay}</p></div>
                     </div>
                     <div className="flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity"><button onClick={(e) => { e.stopPropagation(); setModalType('CARD'); setEditingItem(card); setIsModalOpen(true); }} className="p-2 text-slate-300 hover:text-brand-600"><Edit2 size={14}/></button><button onClick={(e) => { e.stopPropagation(); if(window.confirm("Excluir cartão?")) deleteCard(card.id); }} className="p-2 text-slate-300 hover:text-red-500"><Trash2 size={14}/></button></div>
                  </div>
                  <div className="space-y-4">
                     <div className="flex justify-between items-end">
                        <div><p className="text-[9px] font-black text-slate-400 uppercase">Saldo Devedor Bloqueado</p><p className={`text-lg font-black ${isOver ? 'text-red-600' : 'text-brand-600'}`}>{formatCurrency(used)}</p></div>
                        <div className="text-right"><p className="text-[9px] font-black text-slate-400 uppercase">Disponível</p><p className={`text-sm font-black ${isOver ? 'text-red-600' : 'text-slate-800'}`}>{formatCurrency(card.limit - used)}</p></div>
                     </div>
                     <div className="w-full bg-slate-100 h-1.5 rounded-full overflow-hidden"><div className={`h-full transition-all ${pct > 90 ? 'bg-red-500' : 'bg-brand-500'}`} style={{ width: `${Math.min(100, pct)}%` }} /></div>
                     <div className="flex justify-between text-[9px] font-black uppercase text-slate-400"><span>Limite: {formatCurrency(card.limit)}</span><span>{pct.toFixed(0)}%</span></div>
                  </div>
               </div>
             );
           })}
        </div>
      )}

      {activeTab === 'CARD_DETAILS' && selectedCard && (
        <div className="space-y-8 animate-in slide-in-from-bottom-2 duration-300">
           <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
              <button onClick={() => setActiveTab('CARDS')} className="flex items-center gap-2 text-slate-500 hover:text-brand-600 font-black text-[10px] uppercase tracking-widest"><ArrowLeft size={16} /> Voltar para Cartões</button>
              <div className="flex gap-2 w-full md:w-auto">
                 <button onClick={handleQuickCleanup} className="flex-1 md:flex-none px-4 py-2 bg-emerald-50 text-emerald-600 border border-emerald-100 rounded-xl text-[10px] font-black uppercase flex items-center justify-center gap-2 hover:bg-emerald-100 transition-all"><CheckCircle2 size={14}/> Quitar Atrasados</button>
                 <button onClick={() => setShowAllCardPending(!showAllCardPending)} className={`flex-1 md:flex-none px-4 py-2 rounded-xl text-[10px] font-black uppercase flex items-center justify-center gap-2 transition-all border ${showAllCardPending ? 'bg-brand-600 border-brand-700 text-white shadow-lg' : 'bg-white border-slate-200 text-slate-500 hover:bg-slate-50'}`}>{showAllCardPending ? <Calendar size={14}/> : <ShieldAlert size={14}/>} {showAllCardPending ? 'Mês Atual' : 'Auditoria de Limite Total'}</button>
              </div>
           </div>
           
           <div className="bg-white p-8 rounded-[40px] border border-slate-100 shadow-sm">
              <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-8">
                 <div className="flex items-center gap-4"><div className="p-4 bg-brand-600 text-white rounded-3xl shadow-xl shadow-brand-500/20"><ShoppingBag size={24} /></div><div><h3 className="text-2xl font-black text-slate-800">{showAllCardPending ? 'Auditoria de Saldo Devedor' : 'Lançamentos no Mês'}: {selectedCard.name}</h3><p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">{showAllCardPending ? 'Exibindo cada centavo que bloqueia seu limite total' : `Referência: ${filterMonth}`}</p></div></div>
                 <div className="bg-slate-50 px-6 py-4 rounded-3xl border border-slate-100"><p className="text-[9px] font-black text-slate-400 uppercase mb-1">{showAllCardPending ? 'Dívida Acumulada Listada' : 'Total no Mês'}</p><p className="text-2xl font-black text-brand-600">{formatCurrency(cardTransactions.reduce((acc, t) => acc + t.amount, 0))}</p></div>
              </div>
              
              <div className="overflow-x-auto">
                <table className="w-full text-left">
                  <thead><tr className="text-[10px] font-black uppercase text-slate-400 border-b border-slate-100"><th className="p-6">Mês Ref.</th><th className="p-6">Descrição</th><th className="p-6 text-right">Valor Parcela</th><th className="p-6 text-center">Status</th><th className="p-6 text-center">Ações</th></tr></thead>
                  <tbody className="divide-y divide-slate-50">
                    {cardTransactions.map(t => (
                      <tr key={t.id} className={`hover:bg-slate-50 transition-colors group ${t.referenceMonth < filterMonth ? 'bg-red-50/20' : ''}`}>
                        <td className="p-6 text-xs font-black text-slate-700">{t.referenceMonth} {t.referenceMonth < filterMonth && <span className="ml-2 text-[8px] bg-red-100 text-red-600 px-1.5 py-0.5 rounded font-black uppercase">Atrasado</span>}</td>
                        <td className="p-6 font-black text-slate-800 text-sm">{t.description}</td>
                        <td className="p-6 text-right font-black text-brand-600">{formatCurrency(t.amount)}</td>
                        <td className="p-6 text-center"><span className={`text-[8px] font-black uppercase px-2 py-1 rounded-full border ${t.status === 'pago' ? 'bg-emerald-50 text-emerald-600 border-emerald-100' : 'bg-amber-50 text-amber-600 border-amber-100'}`}>{t.status}</span></td>
                        <td className="p-6 text-center"><div className="flex justify-center gap-2 opacity-0 group-hover:opacity-100 transition-opacity"><button onClick={() => handleOpenTransaction(t)} className="p-2 text-slate-300 hover:text-brand-600"><Edit2 size={16}/></button><button onClick={() => {setItemToDelete(t); setModalType('DELETE_CONFIRM'); setIsModalOpen(true);}} className="p-2 text-slate-300 hover:text-red-500"><Trash2 size={16}/></button></div></td>
                      </tr>
                    ))}
                    {cardTransactions.length === 0 && (<tr><td colSpan={5} className="p-20 text-center text-slate-400 font-bold italic">Nenhum lançamento pendente encontrado para este filtro.</td></tr>)}
                  </tbody>
                </table>
              </div>
           </div>
        </div>
      )}

      {activeTab === 'DEBTS' && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 animate-in slide-in-from-bottom-2 duration-300">
           {debtContracts.map(debt => {
              const pct = debt.totalInstallments > 0 ? ((debt.totalInstallments - debt.installmentsRemaining) / debt.totalInstallments) * 100 : 0;
              return (
                <div key={debt.id} className="bg-white p-6 rounded-[32px] border border-slate-100 shadow-sm group">
                   <div className="flex justify-between items-start mb-4">
                      <div className="flex items-center gap-3">
                         <div className="p-3 bg-red-50 text-red-600 rounded-2xl"><Landmark size={20}/></div>
                         <div><p className="font-black text-slate-800">{debt.creditor}</p><p className="text-[9px] font-black text-slate-400 uppercase truncate max-w-[120px]">{debt.description}</p></div>
                      </div>
                      <button onClick={() => deleteDebtContract(debt.id)} className="p-2 text-slate-300 hover:text-red-500 opacity-0 group-hover:opacity-100 transition-opacity"><Trash2 size={14}/></button>
                   </div>
                   <div className="space-y-4">
                      <div className="flex justify-between items-end"><div><p className="text-[9px] font-black text-slate-400 uppercase">Saldo Devedor</p><p className="text-lg font-black text-red-600">{formatCurrency(debt.totalDebtRemaining)}</p></div><div className="text-right"><p className="text-[9px] font-black text-slate-400 uppercase">Parcela</p><p className="text-sm font-black text-slate-800">{formatCurrency(debt.installmentAmount)}</p></div></div>
                      <div className="w-full bg-slate-100 h-1.5 rounded-full overflow-hidden"><div className="h-full bg-red-500 transition-all" style={{ width: `${pct}%` }} /></div>
                      <div className="flex justify-between text-[9px] font-black uppercase text-slate-400"><span>Original: {formatCurrency(debt.totalLoanValue)}</span><span>{debt.installmentsRemaining} parc. rest.</span></div>
                   </div>
                </div>
              );
           })}
        </div>
      )}

      {/* MODALS */}
      {isModalOpen && modalType === 'DELETE_CONFIRM' && itemToDelete && (
        <div className="fixed inset-0 bg-black/60 z-[70] flex items-center justify-center p-4 backdrop-blur-md">
           <div className="bg-white rounded-[40px] p-10 w-full max-w-md shadow-2xl animate-in zoom-in duration-200 text-center">
              <div className="p-5 bg-red-50 text-red-500 rounded-full mb-6 inline-block"><AlertTriangle size={48} /></div>
              <h3 className="text-2xl font-black text-slate-800 mb-2">Excluir Lançamento</h3>
              <p className="text-slate-500 font-bold text-sm mb-8 leading-relaxed">Este item possui vínculos. Como deseja proceder?</p>
              <div className="grid grid-cols-1 gap-3 w-full">
                 <button onClick={() => confirmDelete('ALL_RELATED')} className="w-full bg-red-600 text-white py-4 rounded-2xl font-black text-[11px] uppercase shadow-lg shadow-red-500/20 hover:bg-red-700 transition-all">Excluir TODAS as parcelas</button>
                 <button onClick={() => confirmDelete('ONLY_THIS')} className="w-full bg-slate-100 text-slate-700 py-4 rounded-2xl font-black text-[11px] uppercase hover:bg-slate-200 transition-all">Excluir apenas este mês</button>
                 <button onClick={() => setIsModalOpen(false)} className="w-full bg-white text-slate-400 py-4 rounded-2xl font-black text-[11px] uppercase">Cancelar</button>
              </div>
           </div>
        </div>
      )}

      {isModalOpen && modalType === 'TRANSACTION' && (
        <div className="fixed inset-0 bg-black/60 z-[60] flex items-center justify-center p-4 backdrop-blur-md">
           <div className="bg-white rounded-[40px] p-10 w-full max-w-lg shadow-2xl overflow-y-auto max-h-[95vh] animate-in zoom-in duration-200">
              <div className="flex justify-between items-center mb-8"><h3 className="text-2xl font-black text-slate-800">{editingItem.id ? 'Editar Lançamento' : 'Novo Lançamento'}</h3><button onClick={() => setIsModalOpen(false)} className="bg-slate-50 p-2 rounded-2xl text-slate-400 hover:text-red-500 transition-all"><X size={24}/></button></div>
              <form onSubmit={handleSaveTransaction} className="space-y-6">
                <div className="grid grid-cols-2 gap-3"><button type="button" onClick={() => setEditingItem({...editingItem, type: 'income'})} className={`py-4 rounded-2xl text-[10px] font-black uppercase border-2 transition-all ${editingItem.type === 'income' ? 'bg-emerald-600 border-emerald-700 text-white shadow-lg' : 'bg-slate-50 border-slate-100 text-slate-500'}`}>Entrada</button><button type="button" onClick={() => setEditingItem({...editingItem, type: 'expense'})} className={`py-4 rounded-2xl text-[10px] font-black uppercase border-2 transition-all ${editingItem.type === 'expense' ? 'bg-red-600 border-red-700 text-white shadow-lg' : 'bg-slate-50 border-slate-100 text-slate-500'}`}>Saída</button></div>
                <div><label className="text-[10px] font-black uppercase text-slate-400 mb-2 block tracking-widest">Descrição</label><input required className="w-full bg-slate-50 border-2 border-slate-100 rounded-2xl p-4 font-black outline-none focus:border-brand-500" value={editingItem.description} onChange={e => setEditingItem({...editingItem, description: e.target.value})} /></div>
                <div className="grid grid-cols-2 gap-4">
                   <div><label className="text-[10px] font-black uppercase text-slate-400 mb-2 block tracking-widest">Método</label><select className="w-full bg-slate-50 border-2 border-slate-100 rounded-2xl p-4 font-black outline-none focus:border-brand-500" value={editingItem.method} onChange={e => setEditingItem({...editingItem, method: e.target.value as PaymentMethod})}><option value="pix">Pix</option><option value="cartao">Cartão</option><option value="boleto">Boleto</option></select></div>
                   {(editingItem.method !== 'cartao') && (<div><label className="text-[10px] font-black uppercase text-slate-400 mb-2 block tracking-widest">Valor</label><input type="number" step="0.01" required className="w-full bg-slate-50 border-2 border-slate-100 rounded-2xl p-4 font-black outline-none focus:border-brand-500" value={editingItem.amount} onChange={e => setEditingItem({...editingItem, amount: parseFloat(e.target.value)})} /></div>)}
                </div>
                {editingItem.method === 'cartao' && (
                  <div className="bg-slate-50 p-6 rounded-3xl border-2 border-slate-100 space-y-4">
                    <p className="text-[10px] font-black uppercase text-brand-600 tracking-widest">Parcelas do Cartão</p>
                    <div className="grid grid-cols-2 gap-4">
                      <div><label className="text-[9px] uppercase text-slate-400">Total (R$)</label><input type="number" step="0.01" className="w-full bg-white border-2 border-slate-200 rounded-xl p-3 text-sm font-black" value={debtCalc.total} onChange={e => { const val = parseFloat(e.target.value) || 0; setDebtCalc({...debtCalc, total: val, part: val / debtCalc.count}); }} /></div>
                      <div><label className="text-[9px] uppercase text-slate-400">Qtd Parc.</label><input type="number" step="1" className="w-full bg-white border-2 border-slate-200 rounded-xl p-3 text-sm font-black" value={debtCalc.count} onChange={e => { const val = Math.max(1, parseInt(e.target.value) || 1); setDebtCalc({...debtCalc, count: val, part: debtCalc.total / val}); }} /></div>
                    </div>
                    <div><label className="text-[9px] uppercase text-slate-400">Escolha o Cartão</label><select required className="w-full bg-white border-2 border-slate-200 rounded-xl p-3 text-sm font-black" value={editingItem.cardId} onChange={e => setEditingItem({...editingItem, cardId: e.target.value})}><option value="">Escolha...</option>{cards.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}</select></div>
                  </div>
                )}
                <div className="grid grid-cols-2 gap-4"><div><label className="text-[10px] font-black uppercase text-slate-400 mb-2 block">Mês Ref.</label><input type="month" required className="w-full bg-slate-50 border-2 border-slate-100 rounded-2xl p-4 font-black" value={editingItem.referenceMonth} onChange={e => setEditingItem({...editingItem, referenceMonth: e.target.value})} /></div><div><label className="text-[10px] font-black uppercase text-slate-400 mb-2 block">Vencimento</label><input type="date" required className="w-full bg-slate-50 border-2 border-slate-100 rounded-2xl p-4 font-black" value={editingItem.date} onChange={e => setEditingItem({...editingItem, date: e.target.value})} /></div></div>
                <button type="submit" className="w-full bg-brand-600 text-white py-5 rounded-2xl font-black shadow-xl shadow-brand-500/30 uppercase text-[11px] tracking-widest hover:bg-brand-700 transition-all">Salvar Lançamento</button>
              </form>
           </div>
        </div>
      )}

      {isModalOpen && modalType === 'CARD' && (
        <div className="fixed inset-0 bg-black/60 z-[60] flex items-center justify-center p-4 backdrop-blur-md"><div className="bg-white rounded-[40px] p-10 w-full max-w-lg shadow-2xl animate-in zoom-in duration-200"><div className="flex justify-between items-center mb-8"><h3 className="text-2xl font-black text-slate-800">{editingItem.id ? 'Editar Cartão' : 'Novo Cartão'}</h3><button onClick={() => setIsModalOpen(false)} className="bg-slate-50 p-2 rounded-2xl text-slate-400 hover:text-red-500 transition-all"><X size={24}/></button></div><form onSubmit={async (e) => { e.preventDefault(); editingItem.id ? await updateCard(editingItem) : await addCard(editingItem); setIsModalOpen(false); }} className="space-y-6"><div><label className="text-[10px] font-black uppercase text-slate-400 mb-2 block tracking-widest">Nome</label><input required className="w-full bg-slate-50 border-2 border-slate-100 rounded-2xl p-4 font-black" value={editingItem.name} onChange={e => setEditingItem({...editingItem, name: e.target.value})} /></div><div className="grid grid-cols-2 gap-4"><div><label className="text-[10px] font-black uppercase text-slate-400 mb-2 block tracking-widest">Fechamento</label><input type="number" required className="w-full bg-slate-50 border-2 border-slate-100 rounded-2xl p-4 font-black" value={editingItem.closingDay} onChange={e => setEditingItem({...editingItem, closingDay: parseInt(e.target.value)})} /></div><div><label className="text-[10px] font-black uppercase text-slate-400 mb-2 block tracking-widest">Vencimento</label><input type="number" required className="w-full bg-slate-50 border-2 border-slate-100 rounded-2xl p-4 font-black" value={editingItem.dueDay} onChange={e => setEditingItem({...editingItem, dueDay: parseInt(e.target.value)})} /></div></div><div><label className="text-[10px] font-black uppercase text-slate-400 mb-2 block tracking-widest">Limite Total</label><input type="number" step="0.01" required className="w-full bg-slate-50 border-2 border-slate-100 rounded-2xl p-4 font-black" value={editingItem.limit} onChange={e => setEditingItem({...editingItem, limit: parseFloat(e.target.value)})} /></div><button type="submit" className="w-full bg-brand-600 text-white py-5 rounded-2xl font-black shadow-xl shadow-brand-500/30 uppercase text-[11px] tracking-widest mt-4">Salvar Cartão</button></form></div></div>
      )}
    </div>
  );
};
