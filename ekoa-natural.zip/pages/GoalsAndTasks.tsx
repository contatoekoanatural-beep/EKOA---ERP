
import React, { useContext, useMemo, useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { AppContext } from '../App';
import { formatDate, getCurrentLocalDate, getLast30DaysDate } from '../constants';
import {
  CheckSquare,
  Square,
  Clock,
  Video,
  FileText,
  Edit,
  Share2,
  BarChart2,
  Plus,
  Trash2,
  CheckCircle,
  Calendar,
  Lock,
  LayoutDashboard,
  X,
  Target,
  ArrowRight,
  AlertCircle,
  Globe,
  XCircle,
  MessageSquare,
  Package,
  DollarSign,
  TrendingUp,
  RefreshCw,
  Repeat,
  Users,
  User as UserIcon,
  ShieldCheck
} from 'lucide-react';
import { Task, TaskStatus, TaskType, Goal, GoalType, PeriodType, RecurrenceConfig, User } from '../types';

const getTypeIcon = (type?: TaskType) => {
  switch(type) {
      case 'Tráfego & Aquisição': return <Share2 size={16} className="text-brand-600" />;
      case 'Atendimento & Conversão': return <MessageSquare size={16} className="text-blue-600" />;
      case 'Operação & Entrega': return <Package size={16} className="text-orange-600" />;
      case 'Financeiro': return <DollarSign size={16} className="text-emerald-600" />;
      case 'TikTok Shop — Produção': return <Video size={16} className="text-purple-600" />;
      case 'TikTok Shop — Performance': return <TrendingUp size={16} className="text-indigo-600" />;
      default: return <CheckSquare size={16} className="text-slate-500" />;
  }
};

const WEEK_DAYS = [
  { label: 'D', value: 0 },
  { label: 'S', value: 1 },
  { label: 'T', value: 2 },
  { label: 'Q', value: 3 },
  { label: 'Q', value: 4 },
  { label: 'S', value: 5 },
  { label: 'S', value: 6 }
];

export const GoalsAndTasks = () => {
  const { 
    tasks, goals, users, currentUser, 
    addTask, updateTask, deleteTask, toggleTaskStatus, 
    addGoal, updateGoal, deleteGoal, 
    can, profileReady 
  } = useContext(AppContext);
  
  const navigate = useNavigate();
  const isAdmin = currentUser?.profile === 'ADMIN';
  
  // Filtros Globais
  const [dateFrom, setDateFrom] = useState<string>('');
  const [dateTo, setDateTo] = useState<string>('');
  const [userFilter, setUserFilter] = useState<string>(isAdmin ? 'all' : (currentUser?.id || ''));
  
  // Estados dos Modais
  const [isTaskModalOpen, setIsTaskModalOpen] = useState(false);
  const [editingTask, setEditingTask] = useState<Task | null>(null);
  const [taskForm, setTaskForm] = useState<Partial<Task>>({});
  
  const [isGoalModalOpen, setIsGoalModalOpen] = useState(false);
  const [editingGoal, setEditingGoal] = useState<Goal | null>(null);
  const [goalForm, setGoalForm] = useState<Partial<Goal>>({});

  const hasAccess = useMemo(() => can('goals'), [can, currentUser, profileReady]);

  // Lista de usuários limpa: Remove "Novo Usuário" e ordena
  const cleanUsersList = useMemo(() => {
    return users
      .filter(u => {
        const name = u.name || '';
        const isGeneric = name.toLowerCase().trim() === 'novo usuário' || name.trim() === '';
        // Assume true se isActive for indefinido (para garantir que Mateus apareça)
        const isActive = u.isActive !== false;
        return !isGeneric && isActive;
      })
      .sort((a, b) => {
        // Coloca o usuário atual (Você) no topo
        if (a.id === currentUser?.id) return -1;
        if (b.id === currentUser?.id) return 1;
        return a.name.localeCompare(b.name);
      });
  }, [users, currentUser]);

  // Lógica de Filtragem Unificada
  const filteredData = useMemo(() => {
    if (!hasAccess) return { tasks: [], goals: [] };

    const matchesDate = (d?: string) => {
        if (!dateFrom && !dateTo) return true;
        if (!d) return false;
        const start = dateFrom || '0000-01-01';
        const end = dateTo || '9999-12-31';
        return d >= start && d <= end;
    };

    const matchesUser = (responsibleId?: string) => {
        if (userFilter === 'all') return true;
        return responsibleId === userFilter;
    };

    return {
        tasks: tasks.filter(t => matchesDate(t.deadline) && matchesUser(t.responsibleId)),
        goals: goals.filter(g => matchesDate(g.endDate) && matchesUser(g.responsibleId))
    };
  }, [tasks, goals, dateFrom, dateTo, userFilter, hasAccess]);

  const kpis = useMemo(() => {
    const today = getCurrentLocalDate();
    const overdue = filteredData.tasks.filter(t => t.status !== 'Concluída' && t.deadline < today).length;
    const pending = filteredData.tasks.filter(t => t.status !== 'Concluída').length;
    return { overdue, pending };
  }, [filteredData]);

  const columns = useMemo(() => {
    return {
      todo: filteredData.tasks.filter(t => t.status === 'A fazer'),
      doing: filteredData.tasks.filter(t => t.status === 'Em andamento'),
      done: filteredData.tasks.filter(t => t.status === 'Concluída')
    };
  }, [filteredData]);

  const handleOpenTaskModal = (task?: Task) => {
    if (!hasAccess) return;
    setEditingTask(task || null);
    
    if (task) {
        setTaskForm({ ...task });
    } else {
        setTaskForm({
            description: '', 
            deadline: getCurrentLocalDate(), 
            responsibleId: (userFilter !== 'all' && userFilter) ? userFilter : currentUser?.id,
            priority: 'Média', 
            status: 'A fazer', 
            type: 'Tráfego & Aquisição', 
            quantity: 1,
            goalId: '',
            isRecurring: false,
            recurrence: {
                frequency: 'Diário',
                daysOfWeek: [],
                endOption: 'Nunca',
                currentOccurrenceCount: 0
            }
        });
    }
    setIsTaskModalOpen(true);
  };

  const handleSaveTask = async (e: React.FormEvent) => {
    e.preventDefault();
    if (editingTask) {
        await updateTask({ ...editingTask, ...taskForm } as Task);
    } else {
        await addTask({ ...taskForm } as Task);
    }
    setIsTaskModalOpen(false);
  };

  const handleOpenGoalModal = (goal?: Goal) => {
    if (!hasAccess) return;
    setEditingGoal(goal || null);
    if (goal) {
        setGoalForm({ ...goal });
    } else {
        setGoalForm({ 
            type: 'Tráfego & Aquisição', 
            description: '',
            period: 'Mensal', 
            startDate: getCurrentLocalDate(), 
            endDate: getCurrentLocalDate(), 
            targetValue: 10, 
            responsibleId: (userFilter !== 'all' && userFilter) ? userFilter : currentUser?.id,
            status: 'Em andamento' 
        });
    }
    setIsGoalModalOpen(true);
  };

  const handleSaveGoal = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
        if (editingGoal) {
            await updateGoal({ ...editingGoal, ...goalForm } as Goal);
        } else {
            await addGoal({ ...goalForm } as any);
        }
        setIsGoalModalOpen(false);
    } catch (err) {
        console.error("Erro ao salvar meta:", err);
    }
  };

  const toggleDay = (day: number) => {
    const currentDays = taskForm.recurrence?.daysOfWeek || [];
    const newDays = currentDays.includes(day) 
        ? currentDays.filter(d => d !== day)
        : [...currentDays, day].sort();
    
    setTaskForm({
        ...taskForm,
        recurrence: {
            ...(taskForm.recurrence as RecurrenceConfig),
            daysOfWeek: newDays
        }
    });
  };

  if (!profileReady) return (
    <div className="flex flex-col items-center justify-center h-[60vh] text-slate-400">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-brand-600 mb-4"></div>
        <p>Sincronizando Metas...</p>
    </div>
  );

  if (!hasAccess) return (
    <div className="flex flex-col items-center justify-center h-[60vh] text-center p-6 bg-white rounded-3xl border border-slate-100 shadow-sm">
        <div className="bg-red-50 text-red-500 p-5 rounded-full mb-4 shadow-inner">
            <Lock size={44} />
        </div>
        <h2 className="text-2xl font-bold text-slate-800">Acesso Restrito</h2>
        <p className="text-slate-500 max-w-sm mt-2 mb-8">Você não possui permissão para gerenciar metas ou tarefas.</p>
        <button 
            onClick={() => navigate('/')}
            className="flex items-center justify-center gap-2 bg-brand-600 text-white px-8 py-3 rounded-xl font-bold hover:bg-brand-700"
        >
            <LayoutDashboard size={20} /> VOLTAR AO DASHBOARD
        </button>
    </div>
  );

  return (
    <div className="space-y-8 pb-10">
      <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center gap-4">
        <div>
          <h2 className="text-2xl font-bold text-slate-800">Metas & Produção</h2>
          <div className="flex items-center gap-2 mt-1">
            <span className={`flex items-center gap-1 text-[9px] font-black uppercase tracking-wider px-2 py-0.5 rounded-full border ${userFilter === 'all' ? 'text-emerald-600 bg-emerald-50 border-emerald-100' : 'text-brand-600 bg-brand-50 border-brand-100'}`}>
                {userFilter === 'all' ? <Globe size={10} /> : <UserIcon size={10} />}
                {userFilter === 'all' ? 'Toda a Equipe' : `Visualizando: ${users.find(u => u.id === userFilter)?.name || 'Responsável'}`}
            </span>
          </div>
        </div>

        <div className="flex flex-col sm:flex-row items-center gap-2 w-full lg:w-auto">
             {isAdmin && (
                <div className="flex items-center gap-2 bg-white border border-slate-200 rounded-xl p-1.5 shadow-sm w-full sm:w-auto">
                    <Users size={16} className="text-slate-400 ml-1" />
                    <select 
                        value={userFilter} 
                        onChange={(e) => setUserFilter(e.target.value)}
                        className="text-xs font-bold text-slate-700 bg-transparent outline-none cursor-pointer pr-4"
                    >
                        <option value="all">Toda a Equipe</option>
                        {cleanUsersList.map(u => (
                            <option key={u.id} value={u.id}>
                                {u.name} {u.profile === 'ADMIN' ? '(ADM)' : ''}
                            </option>
                        ))}
                    </select>
                </div>
             )}

             <div className="flex items-center gap-2 bg-white border border-slate-200 rounded-xl p-1.5 shadow-sm w-full sm:w-auto">
                 <Calendar size={16} className="text-slate-400 ml-1" />
                 <input type="date" className="text-xs font-bold text-slate-700 bg-transparent outline-none cursor-pointer" value={dateFrom} onChange={(e) => setDateFrom(e.target.value)} />
                 <span className="text-slate-300 text-[10px] font-bold">até</span>
                 <input type="date" className="text-xs font-bold text-slate-700 bg-transparent outline-none cursor-pointer" value={dateTo} onChange={(e) => setDateTo(e.target.value)} />
                 {(dateFrom || dateTo) && (
                    <button onClick={() => { setDateFrom(''); setDateTo(''); }} className="ml-1 p-1 text-slate-400 hover:text-red-500">
                        <XCircle size={14} />
                    </button>
                 )}
            </div>
            
            <button onClick={() => handleOpenTaskModal()} className="bg-brand-600 text-white px-5 py-2.5 rounded-xl hover:bg-brand-700 flex items-center gap-2 font-bold shadow-lg shadow-brand-500/20 transition-all w-full sm:w-auto justify-center">
                <Plus size={20} /> NOVA TAREFA
            </button>
        </div>
      </div>

      <section className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="p-6 rounded-2xl border bg-white border-slate-100 shadow-sm flex items-center justify-between">
            <div>
                <p className="text-[10px] font-black uppercase tracking-widest text-slate-400">Pendente Ativo</p>
                <h3 className="text-3xl font-black mt-1 text-slate-800">{kpis.pending}</h3>
            </div>
            <div className="p-3 bg-brand-50 text-brand-600 rounded-xl">
                <Clock size={28} />
            </div>
        </div>
        <div className={`p-6 rounded-2xl border shadow-sm flex items-center justify-between transition-colors ${kpis.overdue > 0 ? 'bg-red-50 border-red-100' : 'bg-white border-slate-100'}`}>
            <div>
                <p className={`text-[10px] font-black uppercase tracking-widest ${kpis.overdue > 0 ? 'text-red-500' : 'text-slate-400'}`}>Atrasadas</p>
                <h3 className={`text-3xl font-black mt-1 ${kpis.overdue > 0 ? 'text-red-700' : 'text-slate-800'}`}>{kpis.overdue}</h3>
            </div>
            <div className={`p-3 rounded-xl ${kpis.overdue > 0 ? 'bg-red-100 text-red-600' : 'bg-slate-100 text-slate-400'}`}>
                <AlertCircle size={28} />
            </div>
        </div>
      </section>

      <section className="bg-white rounded-2xl border border-slate-100 p-6 shadow-sm">
        <div className="flex justify-between items-center mb-6">
            <h3 className="text-xl font-black text-slate-800 flex items-center gap-2"><CheckCircle size={22} className="text-brand-600"/> Metas Estratégicas</h3>
            {isAdmin && (
                <button 
                    onClick={() => handleOpenGoalModal()} 
                    className="bg-brand-50 text-brand-700 hover:bg-brand-100 text-[10px] font-black px-4 py-2 rounded-lg flex items-center gap-2 transition-all border border-brand-200 uppercase"
                >
                    <Plus size={14} /> NOVA META
                </button>
            )}
        </div>
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            {filteredData.goals.length === 0 && <p className="text-slate-400 text-sm py-12 italic text-center w-full col-span-2 bg-slate-50 rounded-2xl border border-dashed border-slate-200">Nenhuma meta {userFilter === 'all' ? 'da equipe' : 'deste responsável'} encontrada.</p>}
            {filteredData.goals.map(g => {
                const linkedTasks = tasks.filter(t => t.goalId === g.id && t.status === 'Concluída');
                const progress = linkedTasks.reduce((acc, t) => acc + (t.quantity || 1), 0);
                const pct = Math.min(100, (progress / g.targetValue) * 100);
                const responsible = users.find(u => u.id === g.responsibleId);
                return (
                    <div key={g.id} className="border border-slate-100 rounded-2xl p-5 bg-slate-50 group relative hover:border-brand-200 hover:bg-white transition-all shadow-sm">
                        <div className="flex justify-between items-start mb-4">
                            <div className="flex-1 pr-16">
                                <h4 className="font-black text-slate-800 text-lg leading-tight group-hover:text-brand-700 transition-colors">{g.description}</h4>
                                <div className="flex flex-wrap items-center gap-3 mt-2">
                                    <span className="text-[9px] font-black uppercase bg-white border border-slate-200 px-2 py-0.5 rounded shadow-sm text-brand-600">{g.type}</span>
                                    <span className="text-[10px] font-bold text-slate-400 flex items-center gap-1"><Calendar size={12} /> Prazo: {formatDate(g.endDate)}</span>
                                    <span className="text-[10px] font-bold text-brand-500 flex items-center gap-1"><UserIcon size={12} /> {responsible?.name || 'Responsável'}</span>
                                </div>
                            </div>
                            {isAdmin && (
                                <div className="absolute top-5 right-5 flex gap-1.5 opacity-0 group-hover:opacity-100 transition-opacity">
                                    <button onClick={() => handleOpenGoalModal(g)} className="p-2 bg-white border border-slate-200 rounded-xl text-slate-400 hover:text-brand-600 hover:border-brand-200 transition-all shadow-sm"><Edit size={16} /></button>
                                    <button onClick={() => { if(window.confirm("Excluir meta?")) deleteGoal(g.id); }} className="p-2 bg-white border border-slate-200 rounded-xl text-slate-400 hover:text-red-500 hover:border-red-200 transition-all shadow-sm"><Trash2 size={16} /></button>
                                </div>
                            )}
                        </div>
                        <div className="mt-6">
                            <div className="flex justify-between text-[11px] font-black uppercase text-slate-500 mb-2">
                                <span className="flex items-center gap-1.5"><Target size={12} className="text-brand-500"/> Progresso: {progress} / {g.targetValue}</span>
                                <span className={pct >= 100 ? 'text-emerald-600' : 'text-brand-600'}>{pct.toFixed(0)}%</span>
                            </div>
                            <div className="w-full bg-slate-200 rounded-full h-3 overflow-hidden shadow-inner border border-slate-100 p-0.5">
                                <div className={`h-full transition-all duration-700 rounded-full ${pct >= 100 ? 'bg-emerald-500 shadow-[0_0_10px_rgba(16,185,129,0.3)]' : 'bg-brand-500 shadow-[0_0_10px_rgba(14,165,233,0.3)]'}`} style={{ width: `${pct}%` }}></div>
                            </div>
                        </div>
                    </div>
                );
            })}
        </div>
      </section>

      <section>
        <div className="flex justify-between items-center mb-6">
            <h3 className="text-xl font-black text-slate-800 flex items-center gap-2"><Clock size={24} className="text-brand-600"/> Pipeline Operacional</h3>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {(['A fazer', 'Em andamento', 'Concluída'] as TaskStatus[]).map(status => (
                <div key={status} className={`rounded-3xl p-5 border transition-all h-fit ${status === 'A fazer' ? 'bg-slate-50 border-slate-200 shadow-inner' : status === 'Em andamento' ? 'bg-blue-50/50 border-blue-100 shadow-inner' : 'bg-emerald-50/50 border-emerald-100 shadow-inner'}`}>
                    <h4 className={`font-black mb-5 flex justify-between items-center text-[11px] tracking-widest uppercase ${status === 'A fazer' ? 'text-slate-500' : status === 'Em andamento' ? 'text-blue-600' : 'text-emerald-600'}`}>
                        {status} 
                        <span className="bg-white border px-3 py-1 rounded-full text-[10px] font-black shadow-sm">{columns[status === 'A fazer' ? 'todo' : status === 'Em andamento' ? 'doing' : 'done'].length}</span>
                    </h4>
                    <div className="space-y-4">
                        {columns[status === 'A fazer' ? 'todo' : status === 'Em andamento' ? 'doing' : 'done'].map(t => {
                            const responsible = users.find(u => u.id === t.responsibleId);
                            return (
                                <div key={t.id} className="bg-white p-4 rounded-2xl border border-slate-100 shadow-sm hover:shadow-xl transition-all group border-l-4" style={{borderLeftColor: t.priority === 'Alta' ? '#ef4444' : t.priority === 'Média' ? '#f59e0b' : '#0ea5e9'}}>
                                    <div className="flex justify-between items-start gap-3">
                                        <button onClick={() => toggleTaskStatus(t.id, t.status === 'Concluída' ? 'A fazer' : 'Concluída')} className={`mt-0.5 flex-shrink-0 transition-all transform active:scale-90 ${t.status === 'Concluída' ? 'text-emerald-500' : 'text-slate-200 hover:text-brand-500'}`}>
                                            {t.status === 'Concluída' ? <CheckCircle size={22} strokeWidth={3} /> : <div className="w-5 h-5 rounded-md border-2 border-current" />}
                                        </button>
                                        <div className="flex-1 overflow-hidden">
                                            <div className="flex items-center gap-1.5 mb-1">
                                                <p className={`text-sm font-bold leading-tight ${t.status === 'Concluída' ? 'text-slate-400 line-through' : 'text-slate-800'}`}>{t.description}</p>
                                                {t.isRecurring && <RefreshCw size={12} className="text-brand-400 animate-spin-slow" />}
                                            </div>
                                            
                                            <div className="flex flex-wrap items-center gap-2 mt-3 text-[9px] text-slate-500 uppercase font-black">
                                                <span className="flex items-center gap-1 bg-slate-50 px-2 py-0.5 rounded-full border border-slate-100">{getTypeIcon(t.type)} {t.type}</span>
                                                <span className={`px-2 py-0.5 rounded-full border ${t.priority === 'Alta' ? 'bg-red-50 text-red-600 border-red-100' : t.priority === 'Média' ? 'bg-amber-50 text-amber-600 border-amber-100' : 'bg-slate-50 border-slate-100'}`}>{t.priority}</span>
                                            </div>

                                            <div className="flex items-center justify-between mt-3 pt-3 border-t border-slate-50">
                                                <div className="flex items-center gap-1.5">
                                                    <div className="w-5 h-5 rounded-full bg-slate-100 flex items-center justify-center text-[10px] font-black text-slate-500 overflow-hidden">
                                                        {responsible?.name?.charAt(0) || '?'}
                                                    </div>
                                                    <span className="text-[10px] font-black text-slate-400 truncate max-w-[80px]">{responsible?.name || 'Responsável'}</span>
                                                </div>
                                                <span className="text-[10px] font-black text-slate-400 uppercase tracking-tighter">{formatDate(t.deadline)}</span>
                                            </div>
                                        </div>
                                        {(isAdmin || t.responsibleId === currentUser?.id) && (
                                            <div className="flex flex-col gap-1.5 opacity-0 group-hover:opacity-100 transition-opacity">
                                                <button onClick={() => handleOpenTaskModal(t)} className="p-2 bg-slate-50 rounded-xl text-slate-400 hover:text-brand-600 hover:bg-brand-50 transition-all"><Edit size={14} /></button>
                                                <button onClick={() => { if(window.confirm("Excluir tarefa?")) deleteTask(t.id); }} className="p-2 bg-slate-50 rounded-xl text-slate-400 hover:text-red-500 hover:bg-red-50 transition-all"><Trash2 size={14} /></button>
                                            </div>
                                        )}
                                    </div>
                                </div>
                            );
                        })}
                        {columns[status === 'A fazer' ? 'todo' : status === 'Em andamento' ? 'doing' : 'done'].length === 0 && (
                            <div className="text-center py-10 text-[10px] font-bold text-slate-400 uppercase border-2 border-dashed border-slate-100 rounded-3xl">Vazio</div>
                        )}
                    </div>
                </div>
            ))}
        </div>
      </section>

      {isTaskModalOpen && (
          <div className="fixed inset-0 bg-black/60 z-[60] flex items-center justify-center p-4 backdrop-blur-md">
            <div className="bg-white rounded-3xl shadow-2xl w-full max-w-xl p-8 animate-in zoom-in duration-200 overflow-y-auto max-h-[95vh]">
                <div className="flex justify-between items-center mb-8">
                    <div>
                        <h3 className="text-2xl font-black text-slate-800">{editingTask ? 'Editar Tarefa' : 'Nova Tarefa'}</h3>
                        <p className="text-xs text-slate-400 font-bold uppercase tracking-widest mt-1">Delegue atividades para sua equipe.</p>
                    </div>
                    <button onClick={() => setIsTaskModalOpen(false)} className="text-slate-400 hover:text-red-500 bg-slate-50 p-2 rounded-xl transition-all"><X size={24} /></button>
                </div>
                <form onSubmit={handleSaveTask} className="space-y-5">
                    <div>
                        <label className="block text-[10px] font-black text-slate-400 uppercase mb-1.5 tracking-widest">Responsável pela Atividade</label>
                        <select 
                            required 
                            className="w-full border-2 border-slate-100 rounded-2xl p-3.5 text-sm bg-slate-50 outline-none focus:border-brand-500 font-bold" 
                            value={taskForm.responsibleId || ''} 
                            onChange={e => setTaskForm({...taskForm, responsibleId: e.target.value})}
                        >
                            <option value="">Selecione um responsável...</option>
                            {cleanUsersList.map(u => (
                                <option key={u.id} value={u.id}>
                                    {u.name} {u.profile === 'ADMIN' ? '(ADM)' : ''} {u.id === currentUser?.id ? '(Você)' : ''}
                                </option>
                            ))}
                        </select>
                    </div>

                    <div>
                        <label className="block text-[10px] font-black text-slate-400 uppercase mb-1.5 tracking-widest">Descrição da Atividade</label>
                        <input required className="w-full border-2 border-slate-100 rounded-2xl p-3.5 text-sm outline-none focus:border-brand-500 transition-all bg-slate-50 font-bold" value={taskForm.description || ''} onChange={e => setTaskForm({...taskForm, description: e.target.value})} placeholder="Ex: Criar roteiro para vídeo de perfume" />
                    </div>
                    
                    <div className="grid grid-cols-2 gap-4">
                        <div>
                            <label className="block text-[10px] font-black text-slate-400 uppercase mb-1.5 tracking-widest">Categoria</label>
                            <select className="w-full border-2 border-slate-100 rounded-2xl p-3.5 text-sm bg-slate-50 outline-none focus:border-brand-500 font-bold" value={taskForm.type || 'Geral'} onChange={e => setTaskForm({...taskForm, type: e.target.value as any})}>
                                <option value="Tráfego & Aquisição">Tráfego & Aquisição</option>
                                <option value="Atendimento & Conversão">Atendimento & Conversão</option>
                                <option value="Operação & Entrega">Operação & Entrega</option>
                                <option value="Financeiro">Financeiro</option>
                                <option value="TikTok Shop — Produção">TikTok Shop — Produção</option>
                                <option value="TikTok Shop — Performance">TikTok Shop — Performance</option>
                                <option value="Geral">Geral / Diversos</option>
                            </select>
                        </div>
                        <div>
                            <label className="block text-[10px] font-black text-slate-400 uppercase mb-1.5 tracking-widest">Prioridade</label>
                            <select className="w-full border-2 border-slate-100 rounded-2xl p-3.5 text-sm bg-slate-50 outline-none focus:border-brand-500 font-bold" value={taskForm.priority || 'Média'} onChange={e => setTaskForm({...taskForm, priority: e.target.value as any})}>
                                <option value="Baixa">🟢 Baixa</option>
                                <option value="Média">🟡 Média</option>
                                <option value="Alta">🔴 Alta</option>
                            </select>
                        </div>
                    </div>

                    <div className="bg-brand-50/50 p-5 rounded-2xl border-2 border-brand-100">
                        <label className="block text-[10px] font-black text-brand-600 uppercase mb-2 tracking-widest flex items-center gap-2"><Target size={12}/> Vínculo com Meta (Opcional)</label>
                        <select className="w-full border-2 border-brand-100 rounded-xl p-3 text-sm bg-white font-black text-brand-800 outline-none" value={taskForm.goalId || ''} onChange={e => setTaskForm({...taskForm, goalId: e.target.value})}>
                            <option value="">Nenhuma meta (Tarefa isolada)</option>
                            {goals.filter(g => g.responsibleId === taskForm.responsibleId).map(g => <option key={g.id} value={g.id}>{g.description}</option>)}
                        </select>
                        <p className="text-[9px] text-brand-400 mt-2 font-bold italic">* Apenas metas do mesmo responsável aparecem aqui.</p>
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                        <div>
                            <label className="block text-[10px] font-black text-slate-400 uppercase mb-1.5 tracking-widest">Data Limite</label>
                            <input type="date" required className="w-full border-2 border-slate-100 rounded-2xl p-3.5 text-sm bg-slate-50 font-bold" value={taskForm.deadline || ''} onChange={e => setTaskForm({...taskForm, deadline: e.target.value})} />
                        </div>
                        <div>
                            <label className="block text-[10px] font-black text-slate-400 uppercase mb-1.5 tracking-widest">Peso / Qtd</label>
                            <input type="number" min="1" required className="w-full border-2 border-slate-100 rounded-2xl p-3.5 text-sm bg-slate-50 font-bold" value={taskForm.quantity || 1} onChange={e => setTaskForm({...taskForm, quantity: parseInt(e.target.value)})} />
                        </div>
                    </div>

                    <div className="bg-slate-50 rounded-2xl border-2 border-slate-200 p-5 space-y-4 shadow-inner">
                        <div className="flex items-center justify-between">
                            <div className="flex items-center gap-2">
                                <Repeat size={18} className="text-brand-600" />
                                <span className="text-[10px] font-black uppercase text-slate-700 tracking-widest">Repetir Tarefa</span>
                            </div>
                            <button 
                                type="button" 
                                onClick={() => setTaskForm({...taskForm, isRecurring: !taskForm.isRecurring})}
                                className={`w-12 h-6 rounded-full transition-all relative flex items-center px-1 ${taskForm.isRecurring ? 'bg-brand-600' : 'bg-slate-300'}`}
                            >
                                <div className={`w-4 h-4 bg-white rounded-full transition-all shadow-md ${taskForm.isRecurring ? 'translate-x-6' : 'translate-x-0'}`} />
                            </button>
                        </div>
                        {taskForm.isRecurring && (
                            <div className="space-y-5 animate-in slide-in-from-top-2 duration-300">
                                <div>
                                    <label className="block text-[10px] font-black text-slate-400 uppercase mb-2 tracking-widest">Frequência</label>
                                    <div className="grid grid-cols-4 gap-2">
                                        {(['Diário', 'Semanal', 'Quinzenal', 'Mensal'] as const).map(f => (
                                            <button 
                                                key={f} 
                                                type="button"
                                                onClick={() => setTaskForm({...taskForm, recurrence: {...(taskForm.recurrence as RecurrenceConfig), frequency: f}})}
                                                className={`py-2 text-[10px] font-black rounded-lg border-2 transition-all ${taskForm.recurrence?.frequency === f ? 'bg-brand-600 border-brand-700 text-white shadow-md' : 'bg-white border-slate-100 text-slate-500 hover:border-brand-200'}`}
                                            >
                                                {f}
                                            </button>
                                        ))}
                                    </div>
                                </div>
                                {(taskForm.recurrence?.frequency === 'Semanal' || taskForm.recurrence?.frequency === 'Quinzenal') && (
                                    <div>
                                        <label className="block text-[10px] font-black text-slate-400 uppercase mb-2 tracking-widest">Dias da Semana</label>
                                        <div className="flex justify-between gap-1">
                                            {WEEK_DAYS.map(day => (
                                                <button 
                                                    key={day.value}
                                                    type="button"
                                                    onClick={() => toggleDay(day.value)}
                                                    className={`w-9 h-9 rounded-full text-[10px] font-black border-2 transition-all ${taskForm.recurrence?.daysOfWeek.includes(day.value) ? 'bg-brand-600 border-brand-700 text-white shadow-md' : 'bg-white border-slate-100 text-slate-500 hover:border-brand-200'}`}
                                                >
                                                    {day.label}
                                                </button>
                                            ))}
                                        </div>
                                    </div>
                                )}
                            </div>
                        )}
                    </div>

                    <div className="flex justify-end gap-3 pt-6 border-t mt-4">
                        <button type="button" onClick={() => setIsTaskModalOpen(false)} className="px-6 py-3.5 text-sm font-black border-2 rounded-2xl text-slate-400 hover:bg-slate-50 transition-all uppercase">CANCELAR</button>
                        <button type="submit" className="px-10 py-3.5 text-sm font-black bg-brand-600 text-white rounded-2xl shadow-xl shadow-brand-500/30 hover:bg-brand-700 transition-all flex items-center gap-2 uppercase">
                           {editingTask ? 'ATUALIZAR' : 'CRIAR TAREFA'} <ArrowRight size={18} />
                        </button>
                    </div>
                </form>
            </div>
          </div>
      )}

      {isGoalModalOpen && (
          <div className="fixed inset-0 bg-black/60 z-[60] flex items-center justify-center p-4 backdrop-blur-md">
            <div className="bg-white rounded-3xl shadow-2xl w-full max-w-lg p-8 animate-in zoom-in duration-200 overflow-y-auto max-h-[95vh]">
                <div className="flex justify-between items-center mb-8">
                    <div>
                        <h3 className="text-2xl font-black text-slate-800">{editingGoal ? 'Editar Meta' : 'Nova Meta Estratégica'}</h3>
                        <p className="text-xs text-slate-400 font-bold uppercase tracking-widest mt-1">Defina objetivos de longo prazo.</p>
                    </div>
                    <button onClick={() => setIsGoalModalOpen(false)} className="text-slate-400 hover:text-red-500 bg-slate-50 p-2 rounded-xl transition-all"><X size={24} /></button>
                </div>
                <form onSubmit={handleSaveGoal} className="space-y-5">
                    <div>
                        <label className="block text-[10px] font-black text-slate-400 uppercase mb-1.5 tracking-widest">Membro Responsável</label>
                        <select 
                            required 
                            className="w-full border-2 border-slate-100 rounded-2xl p-3.5 text-sm bg-slate-50 outline-none focus:border-brand-500 font-bold" 
                            value={goalForm.responsibleId || ''} 
                            onChange={e => setGoalForm({...goalForm, responsibleId: e.target.value})}
                        >
                            <option value="">Selecione um responsável...</option>
                            {cleanUsersList.map(u => (
                                <option key={u.id} value={u.id}>
                                    {u.name} {u.profile === 'ADMIN' ? '(ADM)' : ''} {u.id === currentUser?.id ? '(Você)' : ''}
                                </option>
                            ))}
                        </select>
                    </div>

                    <div>
                        <label className="block text-[10px] font-black text-slate-400 uppercase mb-1.5 tracking-widest">Descrição do Objetivo</label>
                        <input required className="w-full border-2 border-slate-100 rounded-2xl p-3.5 text-sm outline-none focus:border-brand-500 transition-all bg-slate-50 font-bold" value={goalForm.description || ''} onChange={e => setGoalForm({...goalForm, description: e.target.value})} placeholder="Ex: Produção de 50 Criativos / Mês" />
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                        <div>
                            <label className="block text-[10px] font-black text-slate-400 uppercase mb-1.5 tracking-widest">Categoria</label>
                            <select className="w-full border-2 border-slate-100 rounded-2xl p-3.5 text-sm bg-slate-50 outline-none focus:border-brand-500 font-bold" value={goalForm.type || 'Geral'} onChange={e => setGoalForm({...goalForm, type: e.target.value as GoalType})}>
                                <option value="Tráfego & Aquisição">Tráfego & Aquisição</option>
                                <option value="Atendimento & Conversão">Atendimento & Conversão</option>
                                <option value="Operação & Entrega">Operação & Entrega</option>
                                <option value="Financeiro">Financeiro</option>
                                <option value="TikTok Shop — Produção">TikTok Shop — Produção</option>
                                <option value="TikTok Shop — Performance">TikTok Shop — Performance</option>
                            </select>
                        </div>
                        <div>
                            <label className="block text-[10px] font-black text-slate-400 uppercase mb-1.5 tracking-widest">Objetivo Final</label>
                            <input type="number" required min="1" className="w-full border-2 border-slate-100 rounded-2xl p-3.5 text-sm bg-slate-50 font-bold" value={goalForm.targetValue || 1} onChange={e => setGoalForm({...goalForm, targetValue: parseFloat(e.target.value)})} />
                        </div>
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                        <div>
                            <label className="block text-[10px] font-black text-slate-400 uppercase mb-1.5 tracking-widest">Início</label>
                            <input type="date" required className="w-full border-2 border-slate-100 rounded-2xl p-3.5 text-sm bg-slate-50 font-bold" value={goalForm.startDate || ''} onChange={e => setGoalForm({...goalForm, startDate: e.target.value})} />
                        </div>
                        <div>
                            <label className="block text-[10px] font-black text-slate-400 uppercase mb-1.5 tracking-widest">Prazo</label>
                            <input type="date" required className="w-full border-2 border-slate-100 rounded-2xl p-3.5 text-sm bg-slate-50 font-bold" value={goalForm.endDate || ''} onChange={e => setGoalForm({...goalForm, endDate: e.target.value})} />
                        </div>
                    </div>

                    <div className="flex justify-end gap-3 pt-6 border-t mt-4">
                        <button type="button" onClick={() => setIsGoalModalOpen(false)} className="px-6 py-3.5 text-sm font-black border-2 rounded-2xl text-slate-400 hover:bg-slate-50 transition-all uppercase">CANCELAR</button>
                        <button type="submit" className="px-10 py-3.5 text-sm font-black bg-brand-600 text-white rounded-2xl shadow-xl shadow-brand-500/30 hover:bg-brand-700 transition-all flex items-center gap-2 uppercase">
                           {editingGoal ? 'ATUALIZAR' : 'SALVAR META'} <ArrowRight size={18} />
                        </button>
                    </div>
                </form>
            </div>
          </div>
      )}
    </div>
  );
};
