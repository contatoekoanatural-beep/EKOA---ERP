
import React, { useContext, useState, useEffect, useMemo, useRef } from 'react';
import { AppContext } from '../App';
import { formatCurrency, getCurrentLocalDate, getLast30DaysDate } from '../constants';
import { Plus, Edit2, Check, X, Trash2, Folder, Layers, Image as ImageIcon, ChevronRight, Filter, Target, ArrowRight, Trophy, Calendar, ChevronDown, Globe, MousePointer2, Eye } from 'lucide-react';
import { DailyMetric, Campaign, AdSet, Creative } from '../types';

interface EditableItemProps {
  initialValue: string;
  onSave: (val: string) => void;
  onDelete: () => void;
  isSelected?: boolean;
  onClick?: () => void;
}

const EditableItem: React.FC<EditableItemProps> = ({ initialValue, onSave, onDelete, isSelected, onClick }) => {
  const [isEditing, setIsEditing] = useState(false);
  const [value, setValue] = useState(initialValue);

  useEffect(() => setValue(initialValue), [initialValue]);

  const handleSave = (e?: React.FormEvent) => {
    e?.preventDefault();
    if (value.trim() && value !== initialValue) onSave(value);
    setIsEditing(false);
  };

  if (isEditing) {
    return (
      <div className="flex items-center gap-1 mb-2 p-2 bg-white border-2 border-brand-400 rounded-xl shadow-sm animate-in fade-in zoom-in duration-150">
        <input 
            autoFocus
            className="flex-1 border-none bg-transparent px-1 py-1 text-sm outline-none font-bold text-brand-700"
            value={value}
            onChange={(e) => setValue(e.target.value)}
            onBlur={() => handleSave()}
            onKeyDown={(e) => e.key === 'Enter' && handleSave()}
        />
        <button onClick={() => handleSave()} className="text-emerald-600 p-1 hover:bg-emerald-50 rounded-lg"><Check size={16} /></button>
      </div>
    );
  }

  return (
    <div 
        onClick={onClick}
        className={`flex items-center justify-between group mb-2 p-4 rounded-2xl border-2 cursor-pointer transition-all relative ${isSelected ? 'bg-brand-600 border-brand-700 shadow-lg translate-x-1' : 'bg-white border-slate-100 hover:border-brand-200 hover:bg-slate-50'}`}
    >
      <div className="flex-1 flex items-center gap-3 overflow-hidden">
        <span className={`text-sm font-black truncate ${isSelected ? 'text-white' : 'text-slate-700'}`}>{value}</span>
      </div>
      <div className={`flex items-center gap-1 transition-all ${isSelected ? 'opacity-100' : 'opacity-0 group-hover:opacity-100'}`}>
        <button onClick={(e) => { e.stopPropagation(); setIsEditing(true); }} className={`p-1.5 rounded-lg ${isSelected ? 'text-brand-200 hover:text-white hover:bg-white/10' : 'text-slate-400 hover:text-brand-600 hover:bg-brand-50'}`}><Edit2 size={12} /></button>
        <button onClick={(e) => { e.stopPropagation(); if(window.confirm("Deseja excluir este item permanentemente?")) onDelete(); }} className={`p-1.5 rounded-lg ${isSelected ? 'text-brand-200 hover:text-white hover:bg-white/10' : 'text-slate-400 hover:text-red-500 hover:bg-red-50'}`}><Trash2 size={12} /></button>
      </div>
    </div>
  );
};

type PeriodOption = 'hoje' | '7d_passado' | '7d_futuro' | '30d_passado' | '30d_futuro' | 'este_mes' | 'mes_passado' | 'personalizado' | 'tudo';

export const Marketing = () => {
  const { 
      campaigns, adSets, creatives, dailyMetrics, sales,
      addCampaign, updateCampaign, deleteCampaign,
      addAdSet, updateAdSet, deleteAdSet,
      addCreative, updateCreative, deleteCreative,
      addMetric, updateMetric, deleteMetric
  } = useContext(AppContext);
  
  const [activeTab, setActiveTab] = useState<'METRICS' | 'STRUCTURE'>('STRUCTURE');
  const [selectedCampaignId, setSelectedCampaignId] = useState<string | null>(null);
  const [selectedAdSetId, setSelectedAdSetId] = useState<string | null>(null);

  // Filtros de Métricas
  const [metricCampaignFilter, setMetricCampaignFilter] = useState<string>('');
  const [metricCreativesFilter, setMetricCreativesFilter] = useState<string[]>([]);
  const [isCreativeDropdownOpen, setIsCreativeDropdownOpen] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);

  // Períodos para o Ranking
  const [selectedPeriod, setSelectedPeriod] = useState<PeriodOption>('30d_passado');
  const [dateFrom, setDateFrom] = useState<string>(getLast30DaysDate());
  const [dateTo, setDateTo] = useState<string>(getCurrentLocalDate());

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setIsCreativeDropdownOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  // Atualização de datas baseada no período
  useEffect(() => {
    const today = new Date();
    const formatDate = (d: Date) => d.toISOString().split('T')[0];

    switch (selectedPeriod) {
      case 'hoje':
        setDateFrom(formatDate(today)); setDateTo(formatDate(today)); break;
      case '7d_passado': {
        const start = new Date(); start.setDate(today.getDate() - 6);
        setDateFrom(formatDate(start)); setDateTo(formatDate(today)); break;
      }
      case '30d_passado': {
        const start = new Date(); start.setDate(today.getDate() - 29);
        setDateFrom(formatDate(start)); setDateTo(formatDate(today)); break;
      }
      case 'este_mes': {
        const start = new Date(today.getFullYear(), today.getMonth(), 1);
        const end = new Date(today.getFullYear(), today.getMonth() + 1, 0);
        setDateFrom(formatDate(start)); setDateTo(formatDate(end)); break;
      }
      case 'mes_passado': {
        const start = new Date(today.getFullYear(), today.getMonth() - 1, 1);
        const end = new Date(today.getFullYear(), today.getMonth(), 0);
        setDateFrom(formatDate(start)); setDateTo(formatDate(end)); break;
      }
      case 'tudo': setDateFrom(''); setDateTo(''); break;
    }
  }, [selectedPeriod]);

  const isWithinRange = (dateStr?: string | null) => {
      if (!dateFrom && !dateTo) return true;
      if (!dateStr) return false;
      const d = dateStr.split('T')[0];
      const start = dateFrom || '0000-01-01';
      const end = dateTo || '9999-12-31';
      return d >= start && d <= end;
  };

  // Ranking de Criativos
  const creativeRanking = useMemo(() => {
      const stats: Record<string, { id: string, name: string, investment: number, revenue: number, leads: number }> = {};
      const filteredMetrics = dailyMetrics.filter(m => isWithinRange(m.date));
      filteredMetrics.forEach(m => {
          if (!stats[m.creativeId]) stats[m.creativeId] = { id: m.creativeId, name: creatives.find(c => c.id === m.creativeId)?.name || 'Desconhecido', investment: 0, revenue: 0, leads: 0 };
          stats[m.creativeId].investment += m.investment;
          stats[m.creativeId].leads += m.leads;
      });
      sales.forEach(s => {
          if (s.status === 'ENTREGUE' && isWithinRange(s.deliveryDate) && s.creativeId) {
             if (!stats[s.creativeId]) stats[s.creativeId] = { id: s.creativeId, name: creatives.find(c => c.id === s.creativeId)?.name || 'Desconhecido', investment: 0, revenue: 0, leads: 0 };
             stats[s.creativeId].revenue += s.value;
          }
      });
      return Object.values(stats).map(item => ({
          ...item,
          roi: item.investment > 0 ? item.revenue / item.investment : 0,
          profit: item.revenue - item.investment,
          cpl: item.leads > 0 ? item.investment / item.leads : 0
      })).sort((a, b) => b.roi - a.roi);
  }, [dailyMetrics, sales, creatives, dateFrom, dateTo]);

  // Modais
  const [modalType, setModalType] = useState<'CAMPAIGN' | 'ADSET' | 'CREATIVE' | null>(null);
  const [newItemName, setNewItemName] = useState('');
  const [isMetricModalOpen, setIsMetricModalOpen] = useState(false);
  const [editingMetric, setEditingMetric] = useState<DailyMetric | null>(null);
  const [metricForm, setMetricForm] = useState({
    date: new Date().toISOString().split('T')[0],
    campaignId: '',
    creativeData: {} as Record<string, { investment: number, impressions: number, clicks: number, leads: number, adSetId: string }>
  });

  const handleOpenCreateModal = (type: 'CAMPAIGN' | 'ADSET' | 'CREATIVE') => {
      setNewItemName('');
      setModalType(type);
  };

  const handleCreateItem = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newItemName.trim()) return;
    try {
        if (modalType === 'CAMPAIGN') {
            const id = await addCampaign({ name: newItemName, productId: 'p1' });
            setSelectedCampaignId(id);
        } else if (modalType === 'ADSET' && selectedCampaignId) {
            const id = await addAdSet({ name: newItemName, campaignId: selectedCampaignId });
            setSelectedAdSetId(id);
        } else if (modalType === 'CREATIVE' && selectedAdSetId) {
            await addCreative({ name: newItemName, adSetId: selectedAdSetId, format: 'Vídeo' });
        }
        setModalType(null);
    } catch (err) { console.error(err); }
  };

  const openMetricModal = (metric?: DailyMetric) => {
    if (metric) {
      setEditingMetric(metric);
      setMetricForm({
        date: metric.date,
        campaignId: metric.campaignId,
        creativeData: {
          [metric.creativeId]: { 
            investment: metric.investment, 
            impressions: metric.impressions || 0, 
            clicks: metric.clicks || 0, 
            leads: metric.leads,
            adSetId: metric.adSetId
          }
        }
      });
    } else {
      setEditingMetric(null);
      setMetricForm({ 
        date: new Date().toISOString().split('T')[0], 
        campaignId: '', 
        creativeData: {} 
      });
    }
    setIsMetricModalOpen(true);
  };

  const handleSaveMetrics = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!metricForm.campaignId) return;

    // Explicitly casting Object.entries result to any[] to avoid 'unknown' type property access errors during iteration
    const entries = Object.entries(metricForm.creativeData) as [string, any][];
    for (const [cId, data] of entries) {
      if (data.investment > 0 || data.leads > 0) {
        const payload = {
          date: metricForm.date,
          campaignId: metricForm.campaignId,
          adSetId: data.adSetId,
          creativeId: cId,
          investment: data.investment,
          impressions: data.impressions,
          clicks: data.clicks,
          leads: data.leads
        };
        if (editingMetric && cId === editingMetric.creativeId) {
          await updateMetric({ ...editingMetric, ...payload } as DailyMetric);
        } else {
          await addMetric(payload as any);
        }
      }
    }
    setIsMetricModalOpen(false);
  };

  // Lógica de Filtros Cascateados
  const creativesOfCampaign = useMemo(() => {
    if (!metricCampaignFilter) return [];
    const adsOfCampaign = adSets.filter(a => a.campaignId === metricCampaignFilter).map(a => a.id);
    return creatives.filter(c => adsOfCampaign.includes(c.adSetId));
  }, [metricCampaignFilter, adSets, creatives]);

  const calculatedMetrics = dailyMetrics
    .filter(m => {
        const matchesCampaign = !metricCampaignFilter || m.campaignId === metricCampaignFilter;
        const matchesCreative = metricCreativesFilter.length === 0 || metricCreativesFilter.includes(m.creativeId);
        return matchesCampaign && matchesCreative;
    })
    .sort((a, b) => b.date.localeCompare(a.date));

  const filteredAdSets = adSets.filter(a => a.campaignId === selectedCampaignId);
  const filteredCreatives = creatives.filter(c => c.adSetId === selectedAdSetId);

  return (
    <div className="space-y-8 pb-10">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h2 className="text-2xl font-black text-slate-800">Marketing & Tráfego</h2>
          <p className="text-sm text-slate-500 font-medium tracking-tight">Gestão de Criativos e Performance de Canais</p>
        </div>
        <div className="flex bg-white rounded-2xl p-1.5 border border-slate-100 shadow-sm">
            <button onClick={() => setActiveTab('STRUCTURE')} className={`px-6 py-2 rounded-xl text-xs font-black transition-all ${activeTab === 'STRUCTURE' ? 'bg-brand-600 text-white shadow-lg' : 'text-slate-500 hover:bg-slate-50'}`}>ESTRUTURA</button>
            <button onClick={() => setActiveTab('METRICS')} className={`px-6 py-2 rounded-xl text-xs font-black transition-all ${activeTab === 'METRICS' ? 'bg-brand-600 text-white shadow-lg' : 'text-slate-500 hover:bg-slate-50'}`}>MÉTRICAS</button>
        </div>
      </div>

      {activeTab === 'STRUCTURE' && (
        <div className="space-y-12 animate-in fade-in duration-300">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 items-start">
                <div className="bg-white rounded-3xl shadow-sm border border-slate-100 flex flex-col min-h-[500px] overflow-hidden">
                    <div className="p-5 border-b border-slate-50 bg-slate-50/50 flex justify-between items-center">
                        <div className="flex items-center gap-2 text-slate-700 font-black text-[11px] tracking-widest uppercase"><Folder size={16} className="text-brand-600"/> CAMPANHAS <span className="text-slate-300 ml-1">{campaigns.length}</span></div>
                        <button onClick={() => handleOpenCreateModal('CAMPAIGN')} className="bg-brand-50 text-brand-600 hover:bg-brand-100 p-2 rounded-xl transition-all"><Plus size={20} /></button>
                    </div>
                    <div className="p-4 space-y-1 overflow-y-auto max-h-[600px]">
                        {campaigns.map(c => (
                            <EditableItem key={c.id} initialValue={c.name} isSelected={selectedCampaignId === c.id} onClick={() => { setSelectedCampaignId(c.id); setSelectedAdSetId(null); }} onSave={(val) => updateCampaign({...c, name: val})} onDelete={() => deleteCampaign(c.id)} />
                        ))}
                    </div>
                </div>
                <div className={`bg-white rounded-3xl shadow-sm border border-slate-100 flex flex-col min-h-[500px] overflow-hidden transition-all ${!selectedCampaignId ? 'opacity-40 grayscale pointer-events-none' : 'opacity-100'}`}>
                    <div className="p-5 border-b border-slate-50 bg-slate-50/50 flex justify-between items-center">
                        <div className="flex items-center gap-2 text-slate-700 font-black text-[11px] tracking-widest uppercase"><Layers size={16} className="text-indigo-600"/> CONJUNTOS <span className="text-slate-300 ml-1">{filteredAdSets.length}</span></div>
                        <button onClick={() => handleOpenCreateModal('ADSET')} className="bg-indigo-50 text-indigo-600 hover:bg-indigo-100 p-2 rounded-xl transition-all"><Plus size={20} /></button>
                    </div>
                    <div className="p-4 space-y-1 overflow-y-auto max-h-[600px]">
                        {filteredAdSets.map(a => (
                            <EditableItem key={a.id} initialValue={a.name} isSelected={selectedAdSetId === a.id} onClick={() => setSelectedAdSetId(a.id)} onSave={(val) => updateAdSet({...a, name: val})} onDelete={() => deleteAdSet(a.id)} />
                        ))}
                    </div>
                </div>
                <div className={`bg-white rounded-3xl shadow-sm border border-slate-100 flex flex-col min-h-[500px] overflow-hidden transition-all ${!selectedAdSetId ? 'opacity-40 grayscale pointer-events-none' : 'opacity-100'}`}>
                    <div className="p-5 border-b border-slate-50 bg-slate-50/50 flex justify-between items-center">
                        <div className="flex items-center gap-2 text-slate-700 font-black text-[11px] tracking-widest uppercase"><ImageIcon size={16} className="text-purple-600"/> CRIATIVOS <span className="text-slate-300 ml-1">{filteredCreatives.length}</span></div>
                        <button onClick={() => handleOpenCreateModal('CREATIVE')} className="bg-purple-50 text-purple-600 hover:bg-purple-100 p-2 rounded-xl transition-all"><Plus size={20} /></button>
                    </div>
                    <div className="p-4 space-y-1 overflow-y-auto max-h-[600px]">
                        {filteredCreatives.map(c => (
                            <EditableItem key={c.id} initialValue={c.name} onSave={(val) => updateCreative({...c, name: val})} onDelete={() => deleteCreative(c.id)} />
                        ))}
                    </div>
                </div>
            </div>

            <div className="space-y-6 pt-4 border-t border-slate-100">
                <div className="flex flex-col md:flex-row justify-between items-center gap-4">
                    <div className="flex items-center gap-2">
                        <Trophy className="text-yellow-500" size={24} />
                        <h3 className="text-xl font-black text-slate-800">Ranking de Performance</h3>
                    </div>
                    <div className="flex flex-wrap items-center gap-3">
                        <div className="relative">
                            <select 
                                value={selectedPeriod}
                                onChange={(e) => setSelectedPeriod(e.target.value as PeriodOption)}
                                className="appearance-none bg-white border border-slate-200 rounded-xl pl-4 pr-10 py-2.5 text-xs font-black uppercase tracking-widest text-slate-700 shadow-sm focus:outline-none focus:ring-2 focus:ring-brand-500 cursor-pointer"
                            >
                                <option value="hoje">Hoje</option>
                                <option value="7d_passado">Últimos 7 dias</option>
                                <option value="30d_passado">Últimos 30 dias</option>
                                <option value="este_mes">Este mês</option>
                                <option value="mes_passado">Mês passado</option>
                                <option value="tudo">Ver Tudo</option>
                                <option value="personalizado">Personalizado</option>
                            </select>
                            <div className="absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none text-slate-400"><ChevronDown size={14} /></div>
                        </div>
                    </div>
                </div>

                <div className="bg-white rounded-3xl shadow-sm border border-slate-100 overflow-hidden">
                    <div className="overflow-x-auto">
                        <table className="w-full text-left text-sm">
                            <thead className="bg-slate-50 text-slate-500 border-b">
                                <tr>
                                    <th className="p-4 font-black uppercase text-[10px]">Criativo</th>
                                    <th className="p-4 text-right font-black uppercase text-[10px]">Tráfego</th>
                                    <th className="p-4 text-right font-black uppercase text-[10px]">Receita</th>
                                    <th className="p-4 text-right font-black uppercase text-[10px]">ROI</th>
                                    <th className="p-4 text-right font-black uppercase text-[10px]">Lucro (R$)</th>
                                    <th className="p-4 text-right font-black uppercase text-[10px]">CPL</th>
                                </tr>
                            </thead>
                            <tbody>
                                {creativeRanking.map((item, idx) => (
                                    <tr key={item.id} className="border-b last:border-0 hover:bg-slate-50 transition-colors">
                                        <td className="p-4 font-bold text-slate-700 flex items-center gap-3">
                                            <span className="w-6 h-6 flex items-center justify-center bg-slate-100 rounded-lg text-[10px] font-black">{idx + 1}</span>
                                            {item.name}
                                        </td>
                                        <td className="p-4 text-right font-bold text-slate-600">{formatCurrency(item.investment)}</td>
                                        <td className="p-4 text-right font-black text-emerald-600">{formatCurrency(item.revenue)}</td>
                                        <td className={`p-4 text-right font-black ${item.roi >= 2 ? 'text-emerald-600' : 'text-slate-800'}`}>{item.roi.toFixed(2)}x</td>
                                        <td className="p-4 text-right">
                                            <span className={`inline-block px-3 py-1 rounded-xl font-black text-xs ${item.profit > 0 ? 'bg-emerald-100 text-emerald-700' : 'bg-red-100 text-red-700'}`}>{formatCurrency(item.profit)}</span>
                                        </td>
                                        <td className="p-4 text-right font-bold text-slate-500">{item.leads > 0 ? formatCurrency(item.cpl) : <span className="text-slate-300">—</span>}</td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
      )}

      {activeTab === 'METRICS' && (
        <div className="space-y-6 animate-in slide-in-from-bottom-2 duration-300">
            <div className="flex flex-col md:flex-row justify-between items-center gap-4">
                <div className="flex flex-wrap items-center gap-3 w-full md:w-auto">
                    {/* Filtro de Campanha */}
                    <div className="flex items-center gap-2 bg-white p-2 rounded-2xl border border-slate-100 shadow-sm min-w-[200px]">
                        <Filter size={16} className="text-slate-400 ml-3" />
                        <select 
                            className="bg-transparent text-sm focus:outline-none text-slate-700 font-bold p-1 w-full" 
                            value={metricCampaignFilter} 
                            onChange={(e) => {
                                setMetricCampaignFilter(e.target.value);
                                setMetricCreativesFilter([]); // Reseta criativos ao trocar campanha
                            }}
                        >
                            <option value="">Todas Campanhas...</option>
                            {campaigns.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
                        </select>
                    </div>

                    {/* Multi-Filtro de Criativos (Só aparece se campanha selecionada) */}
                    {metricCampaignFilter && (
                        <div className="relative" ref={dropdownRef}>
                            <button 
                                onClick={() => setIsCreativeDropdownOpen(!isCreativeDropdownOpen)}
                                className="bg-white px-4 py-3.5 rounded-2xl border border-slate-100 shadow-sm flex items-center gap-3 text-sm font-bold text-slate-700 hover:bg-slate-50 transition-all min-w-[220px]"
                            >
                                <ImageIcon size={16} className="text-brand-500" />
                                <span className="flex-1 text-left truncate">
                                    {metricCreativesFilter.length === 0 ? 'Todos os Criativos' : `${metricCreativesFilter.length} Selecionado(s)`}
                                </span>
                                <ChevronDown size={14} className={`transition-transform ${isCreativeDropdownOpen ? 'rotate-180' : ''}`} />
                            </button>

                            {isCreativeDropdownOpen && (
                                <div className="absolute top-full left-0 mt-2 w-72 bg-white border border-slate-100 rounded-2xl shadow-2xl z-50 p-4 animate-in fade-in zoom-in duration-150">
                                    <div className="space-y-2 max-h-64 overflow-y-auto pr-2">
                                        <label className="flex items-center gap-3 p-2 hover:bg-slate-50 rounded-xl cursor-pointer group">
                                            <input 
                                                type="checkbox" 
                                                className="w-4 h-4 rounded text-brand-600 focus:ring-brand-500"
                                                checked={metricCreativesFilter.length === 0}
                                                onChange={() => setMetricCreativesFilter([])}
                                            />
                                            <span className="text-xs font-black text-slate-600 uppercase tracking-widest">Todos</span>
                                        </label>
                                        <div className="h-px bg-slate-100 my-2" />
                                        {creativesOfCampaign.map(c => (
                                            <label key={c.id} className="flex items-center gap-3 p-2 hover:bg-slate-50 rounded-xl cursor-pointer group">
                                                <input 
                                                    type="checkbox" 
                                                    className="w-4 h-4 rounded text-brand-600 focus:ring-brand-500"
                                                    checked={metricCreativesFilter.includes(c.id)}
                                                    onChange={() => {
                                                        if (metricCreativesFilter.includes(c.id)) {
                                                            setMetricCreativesFilter(prev => prev.filter(id => id !== c.id));
                                                        } else {
                                                            setMetricCreativesFilter(prev => [...prev, c.id]);
                                                        }
                                                    }}
                                                />
                                                <span className="text-xs font-bold text-slate-700 truncate">{c.name}</span>
                                            </label>
                                        ))}
                                    </div>
                                </div>
                            )}
                        </div>
                    )}
                </div>

                <button onClick={() => openMetricModal()} className="bg-brand-600 text-white px-8 py-3.5 rounded-2xl hover:bg-brand-700 flex items-center gap-2 shadow-xl shadow-brand-500/30 font-black text-xs uppercase tracking-widest transition-all w-full md:w-auto justify-center">
                    <Plus size={18} /> LANÇAR MÉTRICA DIÁRIA
                </button>
            </div>
            <div className="bg-white rounded-3xl shadow-sm border border-slate-100 overflow-x-auto">
                <table className="w-full text-sm text-left">
                    <thead className="bg-slate-50 text-slate-500 border-b border-slate-50">
                        <tr>
                            <th className="p-5 font-black uppercase text-[10px] tracking-widest">Data</th>
                            <th className="p-5 font-black uppercase text-[10px] tracking-widest">Estrutura (Cam > Conj > Cri)</th>
                            <th className="p-5 text-right font-black uppercase text-[10px] tracking-widest">Investimento</th>
                            <th className="p-5 text-right font-black uppercase text-[10px] tracking-widest">CPL</th>
                            <th className="p-5 text-right font-black uppercase text-[10px] tracking-widest">CTR</th>
                            <th className="p-5 text-center font-black uppercase text-[10px] tracking-widest">Ações</th>
                        </tr>
                    </thead>
                    <tbody>
                        {calculatedMetrics.map(m => {
                            const cpl = m.leads > 0 ? m.investment / m.leads : 0;
                            const ctr = m.impressions > 0 ? (m.clicks / m.impressions) * 100 : 0;
                            return (
                                <tr key={m.id} className="border-b border-slate-50 hover:bg-slate-50 transition-colors">
                                    <td className="p-5 font-bold text-slate-700">{new Date(m.date).toLocaleDateString('pt-BR')}</td>
                                    <td className="p-5">
                                        <div className="font-black text-brand-700 uppercase text-[11px] truncate">{creatives.find(c => c.id === m.creativeId)?.name || 'Removido'}</div>
                                        <div className="text-[10px] text-slate-400 font-bold truncate">{campaigns.find(c => c.id === m.campaignId)?.name || '?'} • {adSets.find(a => a.id === m.adSetId)?.name || '?'}</div>
                                    </td>
                                    <td className="p-5 text-right font-black text-slate-800">{formatCurrency(m.investment)}</td>
                                    <td className="p-5 text-right font-black text-brand-600">{formatCurrency(cpl)}</td>
                                    <td className="p-5 text-right font-black text-blue-600">{ctr.toFixed(2)}%</td>
                                    <td className="p-5 text-center">
                                        <div className="flex items-center justify-center gap-3">
                                            <button onClick={() => openMetricModal(m)} className="text-slate-400 hover:text-brand-600 p-2 hover:bg-slate-100 rounded-xl transition-all"><Edit2 size={16} /></button>
                                            <button onClick={() => { if(window.confirm("Excluir esta métrica?")) deleteMetric(m.id); }} className="text-slate-400 hover:text-red-500 p-2 hover:bg-red-50 rounded-xl transition-all"><Trash2 size={16} /></button>
                                        </div>
                                    </td>
                                </tr>
                            );
                        })}
                    </tbody>
                </table>
            </div>
        </div>
      )}

      {/* MODAL DE MÉTRICA DIÁRIA (Lote por Campanha) */}
      {isMetricModalOpen && (
        <div className="fixed inset-0 bg-black/60 z-[70] flex items-center justify-center p-4 backdrop-blur-md animate-in fade-in duration-200">
            <div className="bg-white rounded-3xl shadow-2xl w-full max-w-5xl p-8 animate-in zoom-in duration-200 overflow-y-auto max-h-[95vh]">
                 <div className="flex justify-between items-center mb-8">
                    <div>
                        <h3 className="text-2xl font-black text-slate-800">Lançamento por Campanha</h3>
                        <p className="text-xs text-slate-400 font-bold tracking-tight mt-1">Atualize CPM, CTR e Investimento de múltiplos criativos.</p>
                    </div>
                    <button onClick={() => setIsMetricModalOpen(false)} className="text-slate-400 hover:text-red-500 bg-slate-50 p-2 rounded-xl transition-all"><X size={28} /></button>
                </div>
                
                <form onSubmit={handleSaveMetrics} className="space-y-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                        <div className="bg-slate-50 p-6 rounded-3xl border-2 border-slate-100">
                            <label className="block text-[10px] font-black text-slate-400 uppercase mb-2 tracking-widest">Data dos Dados</label>
                            <input type="date" required className="w-full bg-white border-2 border-slate-200 rounded-2xl p-4 font-black outline-none focus:border-brand-500" value={metricForm.date} onChange={e => setMetricForm({...metricForm, date: e.target.value})} />
                        </div>
                        <div className="bg-slate-50 p-6 rounded-3xl border-2 border-slate-100">
                            <label className="block text-[10px] font-black text-slate-400 uppercase mb-2 tracking-widest">Campanha Alvo</label>
                            <select required className="w-full bg-white border-2 border-slate-200 rounded-2xl p-4 font-black outline-none focus:border-brand-500 disabled:opacity-50" value={metricForm.campaignId} disabled={!!editingMetric}
                                onChange={e => {
                                    const cId = e.target.value;
                                    // Popula os criativos daquela campanha no form
                                    const adsOfCampaign = adSets.filter(a => a.campaignId === cId);
                                    const campaignCreatives = creatives.filter(c => adsOfCampaign.some(a => a.id === c.adSetId));
                                    const initialData: any = {};
                                    campaignCreatives.forEach(c => {
                                        initialData[c.id] = { investment: 0, impressions: 0, clicks: 0, leads: 0, adSetId: c.adSetId };
                                    });
                                    setMetricForm({...metricForm, campaignId: cId, creativeData: initialData});
                                }}>
                                <option value="">Escolha a campanha...</option>
                                {campaigns.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
                            </select>
                        </div>
                    </div>

                    {metricForm.campaignId && (
                        <div className="overflow-hidden border border-slate-100 rounded-[32px] bg-white shadow-sm">
                            <table className="w-full text-sm text-left">
                                <thead className="bg-slate-50 border-b">
                                    <tr className="text-[10px] font-black uppercase text-slate-400">
                                        <th className="p-4 w-1/4">Criativo</th>
                                        <th className="p-4">Investimento</th>
                                        <th className="p-4">Leads</th>
                                        <th className="p-4">Impressões / Cliques</th>
                                        <th className="p-4 text-center">Resultados Estimados</th>
                                    </tr>
                                </thead>
                                <tbody className="divide-y divide-slate-50">
                                    {/* Cast Object.entries result to any[] to avoid 'unknown' property access errors during map */}
                                    {(Object.entries(metricForm.creativeData) as [string, any][]).map(([cId, data]) => {
                                        const cName = creatives.find(c => c.id === cId)?.name || 'Criativo';
                                        const cpm = data.impressions > 0 ? (data.investment / data.impressions) * 1000 : 0;
                                        const ctr = data.impressions > 0 ? (data.clicks / data.impressions) * 100 : 0;

                                        return (
                                            <tr key={cId} className="hover:bg-slate-50/50 transition-colors">
                                                <td className="p-4">
                                                    <p className="font-black text-slate-800 text-xs truncate max-w-[200px]">{cName}</p>
                                                    <p className="text-[9px] text-slate-400 font-bold uppercase">{adSets.find(a => a.id === data.adSetId)?.name || 'Conjunto'}</p>
                                                </td>
                                                <td className="p-4">
                                                    <div className="relative">
                                                        <span className="absolute left-3 top-1/2 -translate-y-1/2 text-[9px] font-black text-slate-400">R$</span>
                                                        <input 
                                                            type="number" step="0.01" className="w-24 bg-slate-50 border border-slate-100 rounded-xl p-2 pl-7 text-xs font-black outline-none focus:border-brand-500" 
                                                            value={data.investment} 
                                                            onChange={e => setMetricForm({
                                                                ...metricForm, 
                                                                creativeData: { ...metricForm.creativeData, [cId]: { ...data, investment: parseFloat(e.target.value) || 0 } }
                                                            })}
                                                        />
                                                    </div>
                                                </td>
                                                <td className="p-4">
                                                    <input 
                                                        type="number" className="w-16 bg-slate-50 border border-slate-100 rounded-xl p-2 text-xs font-black outline-none focus:border-brand-500" 
                                                        value={data.leads} 
                                                        onChange={e => setMetricForm({
                                                            ...metricForm, 
                                                            creativeData: { ...metricForm.creativeData, [cId]: { ...data, leads: parseInt(e.target.value) || 0 } }
                                                        })}
                                                    />
                                                </td>
                                                <td className="p-4">
                                                    <div className="flex gap-2">
                                                        <div className="relative" title="Impressões">
                                                            <Eye size={10} className="absolute left-2 top-1/2 -translate-y-1/2 text-slate-400" />
                                                            <input 
                                                                type="number" className="w-24 bg-slate-50 border border-slate-100 rounded-xl p-2 pl-6 text-xs font-black outline-none focus:border-brand-500" placeholder="Imp" 
                                                                value={data.impressions} 
                                                                onChange={e => setMetricForm({
                                                                    ...metricForm, 
                                                                    creativeData: { ...metricForm.creativeData, [cId]: { ...data, impressions: parseInt(e.target.value) || 0 } }
                                                                })}
                                                            />
                                                        </div>
                                                        <div className="relative" title="Cliques">
                                                            <MousePointer2 size={10} className="absolute left-2 top-1/2 -translate-y-1/2 text-slate-400" />
                                                            <input 
                                                                type="number" className="w-20 bg-slate-50 border border-slate-100 rounded-xl p-2 pl-6 text-xs font-black outline-none focus:border-brand-500" placeholder="Cliq"
                                                                value={data.clicks} 
                                                                onChange={e => setMetricForm({
                                                                    ...metricForm, 
                                                                    creativeData: { ...metricForm.creativeData, [cId]: { ...data, clicks: parseInt(e.target.value) || 0 } }
                                                                })}
                                                            />
                                                        </div>
                                                    </div>
                                                </td>
                                                <td className="p-4">
                                                    <div className="flex flex-col items-center">
                                                        <span className={`text-[10px] font-black ${cpm > 50 ? 'text-orange-500' : 'text-slate-500'}`}>CPM: {formatCurrency(cpm)}</span>
                                                        <span className={`text-[10px] font-black ${ctr < 1 ? 'text-red-500' : 'text-emerald-500'}`}>CTR: {ctr.toFixed(2)}%</span>
                                                    </div>
                                                </td>
                                            </tr>
                                        );
                                    })}
                                </tbody>
                            </table>
                        </div>
                    )}

                    <div className="flex justify-end gap-3 pt-6 border-t mt-4">
                        <button type="button" onClick={() => setIsMetricModalOpen(false)} className="px-8 py-4 text-xs font-black border-2 rounded-2xl text-slate-400 hover:bg-slate-50 transition-all uppercase tracking-widest">CANCELAR</button>
                        <button type="submit" className="px-12 py-4 text-xs font-black bg-brand-600 text-white rounded-2xl shadow-xl shadow-brand-500/30 hover:bg-brand-700 transition-all uppercase tracking-widest">SALVAR DADOS EM LOTE</button>
                    </div>
                </form>
            </div>
        </div>
      )}

      {/* Outros Modais (Criação) */}
      {modalType && (
        <div className="fixed inset-0 bg-black/60 z-[70] flex items-center justify-center p-4 backdrop-blur-md animate-in fade-in duration-200">
            <div className="bg-white rounded-3xl shadow-2xl w-full max-w-md p-8 animate-in zoom-in duration-200">
                <div className="flex justify-between items-center mb-8">
                    <div className="flex items-center gap-3">
                        <div className={`p-3 rounded-2xl ${modalType === 'CAMPAIGN' ? 'bg-brand-50 text-brand-600' : modalType === 'ADSET' ? 'bg-indigo-50 text-indigo-600' : 'bg-purple-50 text-purple-600'}`}>
                            {modalType === 'CAMPAIGN' ? <Folder size={24}/> : modalType === 'ADSET' ? <Layers size={24}/> : <ImageIcon size={24}/>}
                        </div>
                        <div>
                            <h3 className="text-xl font-black text-slate-800">{modalType === 'CAMPAIGN' ? 'Nova Campanha' : modalType === 'ADSET' ? 'Novo Conjunto' : 'Novo Criativo'}</h3>
                            <p className="text-[10px] text-slate-400 font-black uppercase tracking-widest mt-1">Defina o nome do seu item</p>
                        </div>
                    </div>
                    <button onClick={() => setModalType(null)} className="text-slate-400 hover:text-red-500 bg-slate-50 p-2 rounded-xl transition-all"><X size={24} /></button>
                </div>
                <form onSubmit={handleCreateItem} className="space-y-6">
                    <div>
                        <label className="block text-[10px] font-black text-slate-400 uppercase mb-2 tracking-widest">{modalType === 'CAMPAIGN' ? 'Nome da Campanha' : modalType === 'ADSET' ? 'Nome do Conjunto' : 'Nome do Criativo'}</label>
                        <input autoFocus required className="w-full border-2 border-slate-100 rounded-2xl p-4 text-sm outline-none focus:border-brand-500 transition-all font-black text-slate-800 bg-slate-50" value={newItemName} onChange={e => setNewItemName(e.target.value)} placeholder="Ex: [Vendas] Perfume Arabe 01" />
                    </div>
                    <div className="flex gap-3 pt-4">
                        <button type="button" onClick={() => setModalType(null)} className="flex-1 px-6 py-4 text-xs font-black border-2 rounded-2xl text-slate-400 hover:bg-slate-50 transition-all uppercase tracking-widest">CANCELAR</button>
                        <button type="submit" className={`flex-[2] px-6 py-4 text-xs font-black text-white rounded-2xl shadow-xl transition-all flex items-center justify-center gap-2 uppercase tracking-widest ${modalType === 'CAMPAIGN' ? 'bg-brand-600 shadow-brand-500/30' : modalType === 'ADSET' ? 'bg-indigo-600 shadow-indigo-500/30' : 'bg-purple-600 shadow-purple-500/30'}`}>CRIAR ITEM <ArrowRight size={18} /></button>
                    </div>
                </form>
            </div>
        </div>
      )}
    </div>
  );
};
