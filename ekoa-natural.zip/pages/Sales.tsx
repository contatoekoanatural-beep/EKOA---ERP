
import React, { useContext, useState, useMemo, useEffect } from 'react';
import { AppContext } from '../App';
import { Sale, SaleStatus } from '../types';
import { formatCurrency, formatDate, getCurrentLocalDate, getLast30DaysDate } from '../constants';
import { Search, Plus, Edit2, Filter, Trash2, Calendar, CheckCircle, XCircle, DollarSign, ShoppingBag, ArrowRight, ChevronDown } from 'lucide-react';

type PeriodOption = 'hoje' | '7d_passado' | '7d_futuro' | '30d_passado' | '30d_futuro' | 'este_mes' | 'mes_passado' | 'personalizado' | 'tudo';

export const Sales = () => {
  const { sales, addSale, updateSale, deleteSale, campaigns, adSets, creatives, users, frustrationReasons, currentUser } = useContext(AppContext);
  
  const todayStr = getCurrentLocalDate();

  // --- FILTER STATE ---
  const [filterStatus, setFilterStatus] = useState<string>('all');
  const [searchText, setSearchText] = useState('');
  
  // Period Selection (Matching Dashboard logic)
  const [selectedPeriod, setSelectedPeriod] = useState<PeriodOption>('30d_passado');
  const [dateFrom, setDateFrom] = useState<string>(getLast30DaysDate());
  const [dateTo, setDateTo] = useState<string>(getCurrentLocalDate());

  // Lógica para atualizar as datas baseado no período selecionado
  useEffect(() => {
    const today = new Date();
    const format = (d: Date) => d.toISOString().split('T')[0];

    switch (selectedPeriod) {
      case 'hoje':
        setDateFrom(format(today));
        setDateTo(format(today));
        break;
      case '7d_passado': {
        const start = new Date();
        start.setDate(today.getDate() - 6);
        setDateFrom(format(start));
        setDateTo(format(today));
        break;
      }
      case '7d_futuro': {
        const end = new Date();
        end.setDate(today.getDate() + 6);
        setDateFrom(format(today));
        setDateTo(format(end));
        break;
      }
      case '30d_passado': {
        const start = new Date();
        start.setDate(today.getDate() - 29);
        setDateFrom(format(start));
        setDateTo(format(today));
        break;
      }
      case '30d_futuro': {
        const end = new Date();
        end.setDate(today.getDate() + 29);
        setDateFrom(format(today));
        setDateTo(format(end));
        break;
      }
      case 'este_mes': {
        const start = new Date(today.getFullYear(), today.getMonth(), 1);
        const end = new Date(today.getFullYear(), today.getMonth() + 1, 0);
        setDateFrom(format(start));
        setDateTo(format(end));
        break;
      }
      case 'mes_passado': {
        const start = new Date(today.getFullYear(), today.getMonth() - 1, 1);
        const end = new Date(today.getFullYear(), today.getMonth(), 0);
        setDateFrom(format(start));
        setDateTo(format(end));
        break;
      }
      case 'tudo':
        setDateFrom('');
        setDateTo('');
        break;
    }
  }, [selectedPeriod]);

  // Modal State
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingSale, setEditingSale] = useState<Sale | null>(null);

  // Form State
  const [formData, setFormData] = useState<Partial<Sale>>({
    productId: 'p1',
    value: 197,
    deliveryType: 'Logzz',
    status: 'AGENDADO'
  });

  // --- CASCADING DROPDOWN OPTIONS ---
  const filteredAdSets = useMemo(() => {
     return adSets.filter(a => !formData.campaignId || a.campaignId === formData.campaignId);
  }, [adSets, formData.campaignId]);

  const filteredCreatives = useMemo(() => {
     return creatives.filter(c => !formData.adSetId || c.adSetId === formData.adSetId);
  }, [creatives, formData.adSetId]);


  // --- FILTER LOGIC ---
  const filteredSales = useMemo(() => {
    return sales.filter(s => {
      // 1. Text Search
      if (searchText) {
         const term = searchText.toLowerCase();
         const matchName = s.customerName.toLowerCase().includes(term);
         const matchPhone = s.customerPhone.includes(term);
         if (!matchName && !matchPhone) return false;
      }

      // 2. Status Filter
      if (filterStatus !== 'all' && s.status !== filterStatus) return false;

      // 3. Smart Date Filter (Context Aware)
      if (dateFrom || dateTo) {
          let dateToCompare = '';

          // Rule: Status determines which date to filter by
          if (filterStatus === 'ENTREGUE') {
              dateToCompare = s.deliveryDate || ''; 
          } else {
              dateToCompare = s.scheduledDate || '';
          }

          if (!dateToCompare) return false;

          if (dateFrom && dateToCompare < dateFrom) return false;
          if (dateTo && dateToCompare > dateTo) return false;
      }

      return true;
    }).sort((a, b) => {
        if (filterStatus === 'ENTREGUE') {
            return (b.deliveryDate || '').localeCompare(a.deliveryDate || '');
        }
        return (a.scheduledDate || '9999-99-99').localeCompare(b.scheduledDate || '9999-99-99');
    });
  }, [sales, searchText, filterStatus, dateFrom, dateTo]);

  const listSummary = useMemo(() => {
    const count = filteredSales.length;
    const totalValue = filteredSales.reduce((acc, curr) => acc + curr.value, 0);
    return { count, totalValue };
  }, [filteredSales]);

  // --- HANDLERS ---
  const handleOpenModal = (sale?: Sale) => {
    if (sale) {
      setEditingSale(sale);
      setFormData({
        ...sale,
        schedulingDate: sale.schedulingDate,
        scheduledDate: sale.scheduledDate
      });
    } else {
      setEditingSale(null);
      setFormData({
        productId: 'p1',
        value: 197,
        deliveryType: 'Logzz',
        status: 'AGENDADO',
        createdAt: new Date().toISOString(),
        agentId: currentUser?.id,
        schedulingDate: todayStr, 
        scheduledDate: todayStr   
      });
    }
    setIsModalOpen(true);
  };

  const handleDelete = (saleId: string) => {
    if (window.confirm("Tem certeza que deseja excluir esta venda?")) {
      deleteSale(saleId);
    }
  };

  const handleMarkDeliveredToday = (sale: Sale) => {
      updateSale({
          ...sale,
          status: 'ENTREGUE',
          deliveryDate: todayStr
      });
  };

  const handleMarkFrustrated = (sale: Sale) => {
      updateSale({
          ...sale,
          status: 'FRUSTRADO'
      });
  };

  const handleQuickStatusChange = (sale: Sale, newStatus: SaleStatus) => {
    let updates: Partial<Sale> = { status: newStatus };
    if (newStatus === 'ENTREGUE' && !sale.deliveryDate) {
        updates.deliveryDate = todayStr;
    }
    updateSale({ ...sale, ...updates });
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.customerName || !formData.customerPhone) {
        alert("Preencha nome e telefone");
        return;
    }

    let finalData = { ...formData };

    if (finalData.status === 'ENTREGUE' && !finalData.deliveryDate) {
        finalData.deliveryDate = todayStr;
    }
    if (finalData.status !== 'ENTREGUE') {
        finalData.deliveryDate = null;
    }
    if (editingSale) {
        if (editingSale.status === 'AGENDADO' && finalData.scheduledDate !== editingSale.scheduledDate) {
            if (finalData.status === 'AGENDADO') {
                finalData.status = 'REAGENDADO';
            }
        }
    }

    if (editingSale) {
      updateSale({ ...editingSale, ...finalData } as Sale);
    } else {
      addSale({ ...finalData, id: Date.now().toString(), createdAt: new Date().toISOString() } as Sale);
    }
    setIsModalOpen(false);
  };

  const getDateLabel = () => {
      if (filterStatus === 'ENTREGUE') return "Período (Realizado)";
      return "Período (Previsto)";
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <h2 className="text-2xl font-bold text-slate-800">Gestão de Vendas</h2>
        <button 
          onClick={() => handleOpenModal()}
          className="bg-brand-600 text-white px-4 py-2 rounded-lg hover:bg-brand-700 flex items-center gap-2 font-bold shadow-lg shadow-brand-500/20"
        >
          <Plus size={18} /> Nova Venda
        </button>
      </div>

      {/* FILTER BAR */}
      <div className="bg-white p-4 rounded-xl shadow-sm border border-slate-100 flex flex-col lg:flex-row gap-4 items-center">
        
        {/* Search */}
        <div className="relative flex-1 w-full">
          <Search className="absolute left-3 top-2.5 text-slate-400" size={20} />
          <input 
            type="text" 
            placeholder="Buscar por cliente, telefone..." 
            value={searchText}
            onChange={(e) => setSearchText(e.target.value)}
            className="w-full pl-10 pr-4 py-2 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-brand-500 text-sm font-medium"
          />
        </div>
        
        <div className="flex flex-wrap items-center gap-3 w-full lg:w-auto">
             
             {/* Status Filter */}
             <div className="flex items-center gap-2 border border-slate-200 rounded-lg p-1.5 bg-slate-50 flex-1 lg:flex-none">
                <Filter size={16} className="text-slate-400 ml-2" />
                <select 
                    value={filterStatus}
                    onChange={(e) => setFilterStatus(e.target.value)}
                    className="bg-transparent text-xs font-black uppercase tracking-widest focus:outline-none text-slate-700 w-full lg:w-32 cursor-pointer"
                >
                    <option value="all">Todos Status</option>
                    <option value="AGENDADO">Agendado</option>
                    <option value="REAGENDADO">Reagendado</option>
                    <option value="ENTREGUE">Entregue</option>
                    <option value="FRUSTRADO">Frustrado</option>
                </select>
             </div>
             
             {/* NEW DROPDOWN PERIOD FILTER */}
             <div className="relative flex-1 lg:flex-none">
                <div className="absolute -top-2.5 left-2 bg-white px-1 text-[9px] font-black uppercase text-slate-400 z-10">
                    {getDateLabel()}
                </div>
                <select 
                    value={selectedPeriod}
                    onChange={(e) => setSelectedPeriod(e.target.value as PeriodOption)}
                    className="appearance-none bg-white border border-slate-200 rounded-lg pl-4 pr-10 py-2.5 text-xs font-black uppercase tracking-widest text-slate-700 shadow-sm focus:outline-none focus:ring-2 focus:ring-brand-500 cursor-pointer w-full"
                >
                    <option value="hoje">Hoje</option>
                    <option value="7d_passado">Últimos 7 dias</option>
                    <option value="7d_futuro">Próximos 7 dias</option>
                    <option value="30d_passado">Últimos 30 dias</option>
                    <option value="30d_futuro">Próximos 30 dias</option>
                    <option value="este_mes">Este mês</option>
                    <option value="mes_passado">Mês passado</option>
                    <option value="tudo">Ver Tudo</option>
                    <option value="personalizado">Personalizado</option>
                </select>
                <div className="absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none text-slate-400">
                    <ChevronDown size={14} />
                </div>
             </div>

             {/* CUSTOM DATE INPUTS */}
             {selectedPeriod === 'personalizado' && (
                <div className="flex items-center gap-2 bg-white border border-slate-200 rounded-lg p-1.5 shadow-sm animate-in fade-in slide-in-from-right-2 duration-200">
                    <Calendar size={16} className="text-slate-400 ml-1" />
                    <input 
                        type="date" 
                        className="text-[11px] font-bold border-none focus:ring-0 text-slate-700 bg-transparent outline-none cursor-pointer p-0 w-24"
                        value={dateFrom}
                        onChange={(e) => setDateFrom(e.target.value)}
                    />
                    <span className="text-slate-300 text-[9px] font-bold">até</span>
                    <input 
                        type="date" 
                        className="text-[11px] font-bold border-none focus:ring-0 text-slate-700 bg-transparent outline-none cursor-pointer p-0 w-24"
                        value={dateTo}
                        onChange={(e) => setDateTo(e.target.value)}
                    />
                </div>
             )}

        </div>
      </div>

      {/* CONTEXTUAL SUMMARY */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div className="bg-white p-4 rounded-xl border border-slate-100 shadow-sm flex items-center gap-4">
              <div className="p-3 rounded-full bg-slate-100 text-slate-600">
                  <ShoppingBag size={20} />
              </div>
              <div>
                  <p className="text-[10px] text-slate-400 font-black uppercase tracking-widest leading-none mb-1">Vendas Listadas</p>
                  <p className="text-xl font-black text-slate-800">{listSummary.count}</p>
              </div>
          </div>
          
          <div className="bg-white p-4 rounded-xl border border-slate-100 shadow-sm flex items-center gap-4">
              <div className="p-3 rounded-full bg-emerald-50 text-emerald-600">
                  <DollarSign size={20} />
              </div>
              <div>
                  <p className="text-[10px] text-slate-400 font-black uppercase tracking-widest leading-none mb-1">Valor Total</p>
                  <p className="text-xl font-black text-emerald-700">{formatCurrency(listSummary.totalValue)}</p>
              </div>
          </div>
      </div>

      {/* TABLE */}
      <div className="bg-white rounded-xl shadow-sm border border-slate-100 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-sm">
            <thead className="bg-slate-50 border-b border-slate-100">
              <tr>
                <th className="p-4 font-black uppercase text-[10px] text-slate-500 tracking-widest">Cliente</th>
                <th className="p-4 font-black uppercase text-[10px] text-slate-500 tracking-widest">Status</th>
                <th className="p-4 font-black uppercase text-[10px] text-slate-500 tracking-widest">Agendado (WPP)</th>
                <th className="p-4 font-black uppercase text-[10px] text-slate-500 tracking-widest">Entrega Agendada</th>
                <th className="p-4 font-black uppercase text-[10px] text-slate-500 tracking-widest">Entrega Realizada</th>
                <th className="p-4 font-black uppercase text-[10px] text-slate-500 tracking-widest">Valor</th>
                <th className="p-4 font-black uppercase text-[10px] text-slate-500 tracking-widest hidden md:table-cell">Atendente</th>
                <th className="p-4 font-black uppercase text-[10px] text-slate-500 tracking-widest">Ações</th>
              </tr>
            </thead>
            <tbody>
              {filteredSales.map((sale) => (
                <tr key={sale.id} className="border-b border-slate-50 hover:bg-slate-50 transition-colors">
                  <td className="p-4">
                    <div className="font-bold text-slate-800">{sale.customerName}</div>
                    <div className="text-[10px] font-black text-slate-400">{sale.customerPhone}</div>
                  </td>
                  <td className="p-4">
                        <select
                        value={sale.status}
                        onChange={(e) => handleQuickStatusChange(sale, e.target.value as SaleStatus)}
                        className={`px-3 py-1 rounded-full text-[10px] font-black cursor-pointer border-0 ring-1 ring-inset focus:ring-2 focus:ring-inset ${
                            sale.status === 'AGENDADO' ? 'bg-blue-50 text-blue-700 ring-blue-600/20' :
                            sale.status === 'REAGENDADO' ? 'bg-amber-50 text-amber-700 ring-amber-600/20' :
                            sale.status === 'ENTREGUE' ? 'bg-emerald-50 text-emerald-700 ring-emerald-600/20' :
                            'bg-red-50 text-red-700 ring-red-600/20'
                        }`}
                        >
                        <option value="AGENDADO">AGENDADO</option>
                        <option value="REAGENDADO">REAGENDADO</option>
                        <option value="ENTREGUE">ENTREGUE</option>
                        <option value="FRUSTRADO">FRUSTRADO</option>
                        </select>
                  </td>
                  <td className="p-4 text-xs font-bold text-slate-500">
                      {formatDate(sale.schedulingDate || '')}
                  </td>
                  <td className="p-4 text-xs font-black text-blue-700 bg-blue-50/20">
                      {formatDate(sale.scheduledDate || '')}
                  </td>
                  <td className="p-4 text-xs font-black text-emerald-700 bg-emerald-50/20">
                      {sale.deliveryDate ? formatDate(sale.deliveryDate) : '-'}
                  </td>
                  <td className="p-4 font-black text-slate-700">{formatCurrency(sale.value)}</td>
                  <td className="p-4 text-[11px] font-bold text-slate-500 hidden md:table-cell">
                    {users.find(u => u.id === sale.agentId)?.name || 'N/A'}
                  </td>
                  <td className="p-4">
                    <div className="flex items-center gap-2">
                        {(sale.status === 'AGENDADO' || sale.status === 'REAGENDADO') && (
                            <>
                                <button 
                                    onClick={() => handleMarkDeliveredToday(sale)}
                                    className="p-1.5 bg-emerald-100 text-emerald-600 rounded-lg hover:bg-emerald-200 transition-colors"
                                    title="Confirmar Entrega (Hoje)"
                                >
                                    <CheckCircle size={16} />
                                </button>
                                <button 
                                    onClick={() => handleMarkFrustrated(sale)}
                                    className="p-1.5 bg-red-100 text-red-600 rounded-lg hover:bg-red-200 transition-colors"
                                    title="Marcar como Frustrado"
                                >
                                    <XCircle size={16} />
                                </button>
                                <div className="w-px h-4 bg-slate-200 mx-1"></div>
                            </>
                        )}
                      <button 
                        onClick={() => handleOpenModal(sale)}
                        className="p-2 hover:bg-slate-200 rounded-lg text-slate-500 transition-colors"
                        title="Editar"
                      >
                        <Edit2 size={16} />
                      </button>
                      <button 
                        onClick={() => handleDelete(sale.id)}
                        className="p-2 hover:bg-red-50 rounded-lg text-red-400 transition-colors"
                        title="Excluir"
                      >
                        <Trash2 size={16} />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
              {filteredSales.length === 0 && (
                <tr>
                  <td colSpan={9} className="p-16 text-center text-slate-400 font-bold italic">Nenhuma venda encontrada com os filtros atuais.</td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* MODAL */}
      {isModalOpen && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="bg-white rounded-3xl shadow-2xl w-full max-w-2xl max-h-[90vh] overflow-y-auto animate-in zoom-in duration-200">
            <div className="p-8 border-b border-slate-100 flex justify-between items-center">
              <div>
                  <h3 className="text-2xl font-black text-slate-800">{editingSale ? 'Editar Venda' : 'Nova Venda'}</h3>
                  <p className="text-xs font-bold text-slate-400 uppercase tracking-widest mt-1">Lançamento Operacional</p>
              </div>
              <button onClick={() => setIsModalOpen(false)} className="text-slate-300 hover:text-red-500 bg-slate-50 p-2 rounded-xl transition-all"><Plus size={28} className="rotate-45" /></button>
            </div>
            <form onSubmit={handleSave} className="p-8 space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                <div>
                    <label className="block text-[10px] font-black text-slate-400 uppercase mb-1.5 tracking-widest">Nome do Cliente</label>
                    <input required className="w-full border-2 border-slate-100 rounded-2xl p-3.5 text-sm font-bold bg-slate-50 focus:border-brand-500 outline-none transition-all" value={formData.customerName || ''} onChange={e => setFormData({...formData, customerName: e.target.value})} placeholder="Ex: João Silva" />
                </div>
                <div>
                    <label className="block text-[10px] font-black text-slate-400 uppercase mb-1.5 tracking-widest">WhatsApp / Telefone</label>
                    <input required className="w-full border-2 border-slate-100 rounded-2xl p-3.5 text-sm font-bold bg-slate-50 focus:border-brand-500 outline-none transition-all" value={formData.customerPhone || ''} onChange={e => setFormData({...formData, customerPhone: e.target.value})} placeholder="Ex: 11999999999" />
                </div>
                <div>
                    <label className="block text-[10px] font-black text-slate-400 uppercase mb-1.5 tracking-widest">Valor da Venda (R$)</label>
                    <input type="number" step="0.01" required className="w-full border-2 border-slate-100 rounded-2xl p-3.5 text-sm font-black bg-slate-50 focus:border-brand-500 outline-none transition-all" value={formData.value} onChange={e => setFormData({...formData, value: parseFloat(e.target.value)})} />
                </div>
                <div>
                    <label className="block text-[10px] font-black text-slate-400 uppercase mb-1.5 tracking-widest">Logística / Entrega</label>
                    <select className="w-full border-2 border-slate-100 rounded-2xl p-3.5 text-sm font-black bg-slate-50 focus:border-brand-500 outline-none transition-all cursor-pointer" value={formData.deliveryType} onChange={e => setFormData({...formData, deliveryType: e.target.value as any})}>
                        <option value="Logzz">Logzz (Pagto na Entrega)</option>
                        <option value="Correios">Correios (Antecipado)</option>
                    </select>
                </div>
                
                {/* Campaigns Context */}
                <div className="md:col-span-2 grid grid-cols-1 md:grid-cols-3 gap-4 bg-slate-50 p-6 rounded-3xl border-2 border-slate-100">
                    <div className="md:col-span-3 mb-2">
                        <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest flex items-center gap-2"><Filter size={12}/> Origem do Tráfego</p>
                    </div>
                    <div>
                        <label className="block text-[9px] font-black text-slate-400 mb-1 uppercase">Campanha</label>
                        <select 
                            required 
                            className="w-full border-2 border-white rounded-xl p-2.5 text-[11px] font-bold shadow-sm focus:border-brand-500 outline-none" 
                            value={formData.campaignId || ''} 
                            onChange={e => setFormData({
                                ...formData, 
                                campaignId: e.target.value,
                                adSetId: '',
                                creativeId: ''
                            })}
                        >
                            <option value="">Selecione...</option>
                            {campaigns.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
                        </select>
                    </div>
                    <div>
                        <label className="block text-[9px] font-black text-slate-400 mb-1 uppercase">Conjunto</label>
                        <select 
                            required 
                            className="w-full border-2 border-white rounded-xl p-2.5 text-[11px] font-bold shadow-sm focus:border-brand-500 outline-none disabled:opacity-50" 
                            value={formData.adSetId || ''} 
                            onChange={e => setFormData({
                                ...formData, 
                                adSetId: e.target.value,
                                creativeId: ''
                            })}
                            disabled={!formData.campaignId}
                        >
                            <option value="">Selecione...</option>
                            {filteredAdSets.map(a => <option key={a.id} value={a.id}>{a.name}</option>)}
                        </select>
                    </div>
                    <div>
                        <label className="block text-[9px] font-black text-slate-400 mb-1 uppercase">Criativo</label>
                        <select 
                            required 
                            className="w-full border-2 border-white rounded-xl p-2.5 text-[11px] font-bold shadow-sm focus:border-brand-500 outline-none disabled:opacity-50" 
                            value={formData.creativeId || ''} 
                            onChange={e => setFormData({...formData, creativeId: e.target.value})}
                            disabled={!formData.adSetId}
                        >
                            <option value="">Selecione...</option>
                            {filteredCreatives.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
                        </select>
                    </div>
                </div>

                <div>
                    <label className="block text-[10px] font-black text-slate-400 uppercase mb-1.5 tracking-widest">Status Atual</label>
                    <select className="w-full border-2 border-slate-100 rounded-2xl p-3.5 text-sm font-black bg-slate-50 focus:border-brand-500 outline-none transition-all cursor-pointer" value={formData.status} onChange={e => setFormData({...formData, status: e.target.value as SaleStatus})}>
                        <option value="AGENDADO">Agendado</option>
                        <option value="REAGENDADO">Reagendado</option>
                        <option value="ENTREGUE">Entregue</option>
                        <option value="FRUSTRADO">Frustrado</option>
                    </select>
                </div>

                <div>
                    <label className="block text-[10px] font-black text-slate-400 uppercase mb-1.5 tracking-widest">Atendente Responsável</label>
                    <select required className="w-full border-2 border-slate-100 rounded-2xl p-3.5 text-sm font-black bg-slate-50 focus:border-brand-500 outline-none transition-all cursor-pointer" value={formData.agentId || ''} onChange={e => setFormData({...formData, agentId: e.target.value})}>
                         <option value="">Selecione...</option>
                         {users.map(u => <option key={u.id} value={u.id}>{u.name}</option>)}
                    </select>
                </div>

                {/* --- DATE FIELDS --- */}
                <div className="md:col-span-2 grid grid-cols-1 md:grid-cols-3 gap-4 pt-4 border-t border-slate-100">
                     <div>
                        <label className="block text-[10px] font-black text-slate-500 uppercase mb-1 tracking-widest leading-none">Negociação (WPP)</label>
                        <input type="date" className="w-full border-2 border-slate-100 rounded-xl p-2.5 text-xs font-bold bg-slate-50 outline-none" value={formData.schedulingDate || ''} onChange={e => setFormData({...formData, schedulingDate: e.target.value})} />
                        <p className="text-[9px] text-slate-400 mt-1 font-bold">Dia do contato</p>
                     </div>
                     <div>
                        <label className="block text-[10px] font-black text-blue-600 uppercase mb-1 tracking-widest leading-none">Entrega Agendada</label>
                        <input type="date" className="w-full border-2 border-blue-100 rounded-xl p-2.5 text-xs font-black bg-blue-50/30 text-blue-700 outline-none" value={formData.scheduledDate || ''} onChange={e => setFormData({...formData, scheduledDate: e.target.value})} required={formData.status === 'AGENDADO' || formData.status === 'REAGENDADO'} />
                        <p className="text-[9px] text-blue-400 mt-1 font-bold">Data prevista</p>
                     </div>
                     <div>
                        <label className="block text-[10px] font-black text-emerald-600 uppercase mb-1 tracking-widest leading-none">Entrega Realizada</label>
                        <input type="date" className="w-full border-2 border-emerald-100 rounded-xl p-2.5 text-xs font-black bg-emerald-50/30 text-emerald-700 outline-none disabled:opacity-30" value={formData.deliveryDate || ''} onChange={e => setFormData({...formData, deliveryDate: e.target.value})} disabled={formData.status !== 'ENTREGUE'} />
                        <p className="text-[9px] text-emerald-500 mt-1 font-bold">Confirmação final</p>
                     </div>
                </div>

                {formData.status === 'FRUSTRADO' && (
                     <div className="md:col-span-2 animate-in slide-in-from-top-2">
                        <label className="block text-[10px] font-black text-red-500 uppercase mb-1.5 tracking-widest">Motivo da Frustração</label>
                        <select required className="w-full border-2 border-red-100 rounded-2xl p-3.5 text-sm font-black bg-red-50/30 focus:border-red-500 outline-none transition-all cursor-pointer" value={formData.frustrationReasonId || ''} onChange={e => setFormData({...formData, frustrationReasonId: e.target.value})}>
                            <option value="">Selecione o motivo...</option>
                            {frustrationReasons.map(f => <option key={f.id} value={f.id}>{f.name}</option>)}
                        </select>
                     </div>
                )}
              </div>

              <div className="flex gap-3 pt-6 border-t border-slate-100">
                <button type="button" onClick={() => setIsModalOpen(false)} className="flex-1 px-6 py-4 text-xs font-black border-2 border-slate-100 rounded-2xl text-slate-400 hover:bg-slate-50 transition-all uppercase tracking-widest">CANCELAR</button>
                <button type="submit" className="flex-[2] px-6 py-4 text-xs font-black bg-brand-600 text-white rounded-2xl shadow-xl shadow-brand-500/30 hover:bg-brand-700 transition-all uppercase tracking-widest flex items-center justify-center gap-2">
                    SALVAR VENDA <ArrowRight size={18} />
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
