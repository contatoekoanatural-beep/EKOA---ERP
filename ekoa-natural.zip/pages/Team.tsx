
import React, { useContext, useState, useMemo, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { AppContext } from '../App';
import {
  User as UserIcon,
  Edit2,
  Trash2,
  Shield,
  X as XIcon,
  Lock,
  Loader2,
  UserPlus,
  Info,
  Power,
  PowerOff,
  Target,
  Check,
  Briefcase
} from 'lucide-react';
import { User, UserAccess } from '../types';

const DEFAULT_ACCESS: UserAccess = {
    dashboard: true,
    sales: true,
    marketing: true,
    finance: true,
    goals: true,
    team: false,
};

const FULL_ACCESS: UserAccess = {
  dashboard: true,
  sales: true,
  marketing: true,
  finance: true,
  team: true,
  goals: true,
};

export const Team = () => {
  const {
    users,
    currentUser,
    addUser,
    updateUser,
    deleteUser,
    can,
    profileReady
  } = useContext(AppContext);

  const navigate = useNavigate();
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingUser, setEditingUser] = useState<User | null>(null);
  
  const [userForm, setUserForm] = useState<{
    name: string;
    email: string;
    role: 'admin' | 'staff';
    isActive: boolean;
    access: UserAccess;
  }>({
    name: '',
    email: '',
    role: 'staff',
    isActive: true,
    access: DEFAULT_ACCESS
  });

  const canManageTeam = useMemo(() => {
    if (!profileReady) return false;
    return can('team');
  }, [can, profileReady]);

  const sortedUsers = useMemo(() => {
    if (!canManageTeam) return [];
    return [...users].sort((a, b) => {
        const aIsAdmin = String(a.role).toLowerCase() === 'admin';
        const bIsAdmin = String(b.role).toLowerCase() === 'admin';
        if (aIsAdmin && !bIsAdmin) return -1;
        if (!aIsAdmin && bIsAdmin) return 1;
        return a.name.localeCompare(b.name);
    });
  }, [users, canManageTeam]);

  const handleOpenModal = (u?: User) => {
    if (!canManageTeam) return;
    if (u) {
      setEditingUser(u);
      setUserForm({ 
          name: u.name || '', 
          email: u.email || '', 
          role: (u.role as 'admin' | 'staff') || 'staff', 
          isActive: u.isActive ?? true,
          access: { ...DEFAULT_ACCESS, ...(u.access || {}) }
      });
    } else {
      setEditingUser(null);
      setUserForm({
        name: '',
        email: '',
        role: 'staff',
        isActive: true,
        access: { ...DEFAULT_ACCESS, team: false }
      });
    }
    setIsModalOpen(true);
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!canManageTeam || !userForm.name.trim() || !userForm.email.trim()) return;

    try {
        const isNewAdmin = userForm.role === 'admin';
        const payload = {
            ...userForm,
            profile: userForm.role.toUpperCase(),
            // Se for admin, garante acesso total. Se for staff, mantém o que foi marcado no form.
            access: isNewAdmin ? FULL_ACCESS : userForm.access,
        };

        if (editingUser) {
            await updateUser({ ...editingUser, ...payload } as User);
        } else {
            await addUser(payload as any);
        }
        setIsModalOpen(false);
    } catch (err) {
        console.error(err);
        alert("Erro ao salvar dados do membro.");
    }
  };

  const toggleStatus = async (user: User) => {
    if (!canManageTeam || user.id === currentUser?.id) return;
    const currentIsActive = user.isActive ?? true;
    const newStatus = !currentIsActive;
    if (window.confirm(`Deseja ${newStatus ? 'Ativar' : 'Desativar'} este usuário?`)) {
        await updateUser({ ...user, isActive: newStatus });
    }
  };

  const handleDeleteUser = async (user: User) => {
      if (!canManageTeam || user.id === currentUser?.id) return;
      if (window.confirm(`Tem certeza que deseja excluir ${user.name}? Esta ação não pode ser desfeita.`)) {
          await deleteUser(user.id);
      }
  };

  const toggleAccess = (key: keyof UserAccess) => {
    setUserForm(prev => ({
        ...prev,
        access: {
            ...prev.access,
            [key]: !prev.access[key]
        }
    }));
  };

  if (!profileReady) {
    return (
        <div className="flex flex-col items-center justify-center h-[60vh] text-slate-500">
            <Loader2 className="w-10 h-10 animate-spin text-brand-600 mb-4" />
            <p className="font-medium text-sm">Carregando permissões...</p>
        </div>
    );
  }

  if (!canManageTeam) {
    return (
        <div className="flex flex-col items-center justify-center h-[60vh] text-center p-6 bg-white rounded-3xl border border-slate-100 shadow-sm">
            <div className="bg-amber-50 text-amber-500 p-5 rounded-full mb-4 shadow-inner">
                <Lock size={44} />
            </div>
            <h2 className="text-2xl font-bold text-slate-800">Acesso Administrativo Restrito</h2>
            <p className="text-slate-500 max-w-sm mt-2 mb-8 text-sm">Sua conta não possui permissão para gerenciar a equipe. Utilize os módulos liberados para você.</p>
            <div className="flex flex-col sm:flex-row gap-3 w-full max-w-md">
                {can('goals') && (
                    <button 
                        onClick={() => navigate('/metas')}
                        className="flex-1 flex items-center justify-center gap-2 bg-brand-600 text-white py-3 rounded-xl font-bold hover:bg-brand-700 transition-all shadow-lg shadow-brand-500/20"
                    >
                        <Target size={18} /> IR PARA METAS & TAREFAS
                    </button>
                )}
                <button 
                    onClick={() => navigate('/')}
                    className="flex-1 flex items-center justify-center gap-2 bg-white border border-slate-200 text-slate-700 py-3 rounded-xl font-bold hover:bg-slate-50 transition-all"
                >
                    VOLTAR AO INÍCIO
                </button>
            </div>
        </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h2 className="text-2xl font-bold text-slate-800">Equipe & Permissões</h2>
          <p className="text-sm text-slate-500">Controle o acesso dos membros ao sistema.</p>
        </div>
        <button 
            onClick={() => handleOpenModal()}
            className="bg-brand-600 text-white px-5 py-2.5 rounded-xl font-bold flex items-center gap-2 shadow-lg shadow-brand-500/20 hover:bg-brand-700 transition-all"
        >
            <UserPlus size={20} /> ADICIONAR MEMBRO
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {sortedUsers.map(u => {
          const active = u.isActive ?? true;
          const isAdmin = String(u.role).toLowerCase() === 'admin';
          return (
            <div
              key={u.id}
              className={`bg-white p-5 rounded-xl border flex flex-col justify-between transition-all hover:shadow-md relative ${!active ? 'opacity-60 grayscale' : ''} ${u.id === currentUser?.id ? 'ring-2 ring-brand-500 border-brand-200' : 'border-slate-100 shadow-sm'}`}
            >
              <div className="flex items-start gap-4 mb-4">
                <div className={`w-12 h-12 rounded-full flex items-center justify-center text-white font-bold text-lg ${isAdmin ? 'bg-purple-600 shadow-lg shadow-purple-500/20' : 'bg-slate-400'}`}>
                  {u.name?.charAt(0).toUpperCase() || '?'}
                </div>
                <div className="flex-1 overflow-hidden">
                  <div className="flex items-center gap-2">
                      <h4 className="font-bold text-slate-800 truncate">{u.name}</h4>
                      {u.id === currentUser?.id && <span className="bg-brand-100 text-brand-700 text-[9px] px-1.5 py-0.5 rounded-full font-black">VOCÊ</span>}
                  </div>
                  <p className="text-xs text-slate-500 truncate font-medium">{u.email}</p>
                  <div className="flex items-center gap-2 mt-1">
                      <span className={`text-[9px] font-black uppercase px-2 py-0.5 rounded-full border ${isAdmin ? 'bg-purple-50 text-purple-700 border-purple-100' : 'bg-slate-50 text-slate-600 border-slate-100'}`}>
                          {isAdmin ? 'ADMINISTRADOR' : 'COLABORADOR'}
                      </span>
                  </div>
                </div>
              </div>

              <div className="pt-4 border-t border-slate-50">
                  <p className="text-[10px] font-bold text-slate-400 uppercase mb-2 tracking-widest">Módulos Liberados:</p>
                  <div className="flex flex-wrap gap-1 mb-4 min-h-[22px]">
                      {isAdmin ? (
                          <span className="text-[9px] bg-purple-50 text-purple-600 px-2 py-0.5 rounded-full border border-purple-100 font-black uppercase tracking-tighter">
                              ACESSO TOTAL LIBERADO
                          </span>
                      ) : (
                          Object.entries(u.access || DEFAULT_ACCESS).map(([key, val]) => (
                              val && (
                                  <span key={key} className="text-[9px] bg-slate-50 text-slate-600 px-2 py-0.5 rounded-full border border-slate-100 font-black uppercase tracking-tighter">
                                      {key}
                                  </span>
                              )
                          ))
                      )}
                      {!isAdmin && !Object.values(u.access || {}).some(v => v) && <span className="text-[10px] text-slate-300 italic font-bold">Sem acesso configurado</span>}
                  </div>

                  <div className="flex items-center gap-2">
                      <button
                          onClick={() => handleOpenModal(u)}
                          className="flex-1 flex items-center justify-center gap-1.5 py-2.5 rounded-xl border border-slate-200 text-slate-600 text-xs font-black hover:bg-slate-50 transition-colors uppercase tracking-widest"
                      >
                          <Edit2 size={12} /> CONFIGURAR
                      </button>
                      <div className="flex gap-1">
                          {u.id !== currentUser?.id && (
                              <button 
                                  onClick={() => toggleStatus(u)} 
                                  className={`p-2.5 rounded-xl border transition-colors ${active ? 'border-amber-100 text-amber-500 hover:bg-amber-50' : 'border-emerald-100 text-emerald-500 hover:bg-emerald-50'}`}
                                  title={active ? 'Desativar' : 'Ativar'}
                              >
                                  {active ? <PowerOff size={16} /> : <Power size={16} />}
                              </button>
                          )}
                          {u.id !== currentUser?.id && (
                              <button 
                                  onClick={() => handleDeleteUser(u)} 
                                  className="p-2.5 rounded-xl border border-red-100 text-red-500 hover:bg-red-50 transition-colors"
                                  title="Excluir"
                              >
                                  <Trash2 size={16} />
                              </button>
                          )}
                      </div>
                  </div>
              </div>
            </div>
          );
        })}
      </div>

      {isModalOpen && (
        <div className="fixed inset-0 bg-black/60 flex items-center justify-center z-50 p-4 backdrop-blur-md">
          <div className="bg-white rounded-3xl shadow-2xl p-8 w-full max-w-lg space-y-6 animate-in fade-in zoom-in duration-200 overflow-y-auto max-h-[95vh]">
            <div className="flex justify-between items-center border-b border-slate-50 pb-6">
                <div>
                    <h3 className="text-2xl font-black text-slate-800">{editingUser ? 'Editar Membro' : 'Novo Membro'}</h3>
                    <p className="text-[10px] text-slate-400 font-black uppercase tracking-widest mt-1">Definição de Perfil e Acessos</p>
                </div>
                <button onClick={() => setIsModalOpen(false)} className="text-slate-400 hover:text-red-500 bg-slate-50 p-2 rounded-xl transition-all"><XIcon size={24} /></button>
            </div>

            <form onSubmit={handleSave} className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                        <label className="block text-[10px] font-black text-slate-400 uppercase mb-2 tracking-widest">Nome Completo</label>
                        <input required className="w-full border-2 border-slate-100 rounded-2xl p-4 text-sm font-black text-slate-800 outline-none focus:border-brand-500 bg-slate-50" value={userForm.name} onChange={e => setUserForm({...userForm, name: e.target.value})} />
                    </div>
                    <div>
                        <label className="block text-[10px] font-black text-slate-400 uppercase mb-2 tracking-widest">E-mail de Login</label>
                        <input required type="email" className="w-full border-2 border-slate-100 rounded-2xl p-4 text-sm font-black text-slate-800 outline-none focus:border-brand-500 bg-slate-50" value={userForm.email} onChange={e => setUserForm({...userForm, email: e.target.value})} />
                    </div>
                </div>

                <div className="bg-slate-50 p-6 rounded-3xl border-2 border-slate-100">
                    <label className="block text-[10px] font-black text-slate-400 uppercase mb-3 tracking-widest flex items-center gap-2"><Briefcase size={12}/> Perfil de Usuário</label>
                    <div className="grid grid-cols-2 gap-3">
                        <button 
                            type="button" 
                            onClick={() => setUserForm({...userForm, role: 'staff'})}
                            className={`flex flex-col items-center justify-center p-4 rounded-2xl border-2 transition-all ${userForm.role === 'staff' ? 'bg-white border-brand-500 text-brand-700 shadow-md' : 'bg-slate-100 border-transparent text-slate-400 hover:bg-slate-200'}`}
                        >
                            <span className="text-xs font-black uppercase">Colaborador</span>
                            <span className="text-[9px] font-bold mt-1 opacity-70">Acesso Limitado</span>
                        </button>
                        <button 
                            type="button" 
                            onClick={() => setUserForm({...userForm, role: 'admin'})}
                            className={`flex flex-col items-center justify-center p-4 rounded-2xl border-2 transition-all ${userForm.role === 'admin' ? 'bg-white border-purple-500 text-purple-700 shadow-md' : 'bg-slate-100 border-transparent text-slate-400 hover:bg-slate-200'}`}
                        >
                            <span className="text-xs font-black uppercase">Administrador</span>
                            <span className="text-[9px] font-bold mt-1 opacity-70">Acesso Total</span>
                        </button>
                    </div>
                </div>

                {userForm.role === 'staff' && (
                    <div className="bg-white p-6 rounded-3xl border-2 border-slate-100 space-y-4">
                        <p className="text-[10px] font-black text-slate-400 flex items-center gap-2 uppercase tracking-widest"><Shield size={12} className="text-brand-600"/> Módulos Disponíveis:</p>
                        <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                            {[
                                { key: 'dashboard', label: 'Dashboard' },
                                { key: 'sales', label: 'Vendas' },
                                { key: 'marketing', label: 'Marketing' },
                                { key: 'finance', label: 'Financeiro' },
                                { key: 'goals', label: 'Metas' }
                            ].map(perm => (
                                <button 
                                    key={perm.key}
                                    type="button"
                                    onClick={() => toggleAccess(perm.key as keyof UserAccess)}
                                    className={`flex flex-col items-center justify-center p-3 rounded-xl border-2 transition-all ${
                                        (userForm.access as any)[perm.key] 
                                        ? 'bg-brand-50 border-brand-500 text-brand-700' 
                                        : 'bg-slate-50 border-transparent text-slate-400 hover:bg-slate-100'
                                    }`}
                                >
                                    <span className="text-[9px] font-black uppercase">{perm.label}</span>
                                    {(userForm.access as any)[perm.key] ? <Check strokeWidth={4} size={14} className="mt-1" /> : <div className="w-3.5 h-3.5 rounded-full border-2 border-slate-200 mt-1" />}
                                </button>
                            ))}
                        </div>
                    </div>
                )}

                {userForm.role === 'admin' && (
                    <div className="bg-purple-50 p-4 rounded-2xl border-2 border-purple-100 flex items-center gap-3 animate-in fade-in slide-in-from-top-2">
                        <Info size={20} className="text-purple-600 flex-shrink-0" />
                        <p className="text-[10px] font-bold text-purple-700 leading-tight">
                            Administradores possuem acesso total a todos os módulos, incluindo gestão de equipe e configurações críticas.
                        </p>
                    </div>
                )}

                <div className="flex justify-end gap-3 pt-6 border-t border-slate-50">
                  <button type="button" onClick={() => setIsModalOpen(false)} className="flex-1 py-4 text-xs font-black rounded-2xl border-2 border-slate-100 text-slate-400 hover:bg-slate-50 transition-colors uppercase tracking-widest">CANCELAR</button>
                  <button type="submit" className="flex-[2] py-4 text-xs font-black rounded-2xl bg-brand-600 text-white shadow-xl shadow-brand-500/30 hover:bg-brand-700 transition-all uppercase tracking-widest flex items-center justify-center gap-2">
                      {editingUser ? 'ATUALIZAR MEMBRO' : 'SALVAR NOVO MEMBRO'} <Check size={18} />
                  </button>
                </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
