
export type Role = 'admin' | 'staff' | string;
export type AccessProfile = 'ADMIN' | 'COLABORADOR';

export interface UserAccess {
  dashboard: boolean;
  sales: boolean;
  marketing: boolean;
  finance: boolean;
  team: boolean;
  goals: boolean;
}

export interface User {
  id: string;
  name: string;
  email?: string;
  role: Role;
  isActive: boolean;
  profile: AccessProfile | string;
  access: UserAccess;
  createdAt?: any;
  updatedAt?: any;
}

export interface Product {
  id: string;
  name: string;
  active: boolean;
}

export interface Campaign {
  id: string;
  name: string;
  productId: string;
  objective?: string;
  status: 'Ativa' | 'Pausada';
}

export interface AdSet {
  id: string;
  campaignId: string;
  name: string;
  segmentationDesc?: string;
  status: 'Ativo' | 'Pausado';
}

export interface Creative {
  id: string;
  adSetId: string;
  name: string;
  format: 'Vídeo' | 'Imagem' | 'Carrossel';
  observations?: string;
}

export interface DailyMetric {
  id: string;
  date: string; // ISO YYYY-MM-DD
  campaignId: string;
  adSetId: string;
  creativeId: string;
  investment: number;
  impressions: number;
  clicks: number;
  leads: number;
}

export interface FrustrationReason {
  id: string;
  name: string;
  category?: string;
}

export type SaleStatus = 'AGENDADO' | 'REAGENDADO' | 'ENTREGUE' | 'FRUSTRADO';
export type DeliveryType = 'Logzz' | 'Correios';

export interface Sale {
  id: string;
  createdAt: string;
  status: SaleStatus;
  productId: string;
  customerName: string;
  customerPhone: string;
  campaignId: string;
  adSetId: string;
  creativeId: string;
  agentId: string;
  value: number;
  deliveryType: DeliveryType;
  schedulingDate?: string;
  scheduledDate?: string;
  deliveryDate?: string | null;
  frustrationReasonId?: string;
  observations?: string;
}

// --- UNIFIED FINANCE TYPES ---

export type TransactionType = 'income' | 'expense';
export type TransactionNature = 'avulso' | 'recorrente' | 'parcela';
export type TransactionStatus = 'previsto' | 'pago';
export type PaymentMethod = 'pix' | 'cartao' | 'boleto' | 'dinheiro' | 'outro';

export interface Transaction {
  id: string;
  type: TransactionType;
  description: string;
  amount: number;
  method: PaymentMethod;
  status: TransactionStatus;
  date: string; // YYYY-MM-DD (Payment date / Due date)
  referenceMonth: string; // YYYY-MM (Accounting month)
  category: string;
  nature: TransactionNature;
  cardId?: string;
  contractId?: string; // Link to DebtContract
  installmentsInfo?: {
    current: number;
    total: number;
  };
  recurrenceId?: string;
  createdAt?: any;
}

export interface CardConfig {
  id: string;
  name: string;
  closingDay: number;
  dueDay: number;
  limit: number;
}

export interface DebtContract {
  id: string;
  creditor: string;
  description: string;
  totalLoanValue: number;
  totalDebtRemaining: number;
  installmentAmount: number;
  totalInstallments: number;
  installmentsRemaining: number;
  status: 'Ativo' | 'Quitado';
  cardId?: string;
  startDate: string;
  dueDay: number;
}

// --- GOALS AND TASKS ---

export type GoalType = 
  | 'Tráfego & Aquisição' 
  | 'Atendimento & Conversão' 
  | 'Operação & Entrega' 
  | 'Financeiro' 
  | 'TikTok Shop — Produção' 
  | 'TikTok Shop — Performance' 
  | string;

export type PeriodType = 'Diário' | 'Semanal' | 'Mensal' | 'Personalizado';

export interface Goal {
  id: string;
  type: GoalType;
  description: string;
  period: PeriodType;
  startDate: string;
  endDate: string;
  targetValue: number;
  responsibleId: string;
  status: 'Em andamento' | 'Atingida' | 'Não atingida' | 'Atrasada';
}

export type TaskStatus = 'A fazer' | 'Em andamento' | 'Concluída';
export type Priority = 'Baixa' | 'Média' | 'Alta';

export type TaskType = 
  | 'Tráfego & Aquisição' 
  | 'Atendimento & Conversão' 
  | 'Operação & Entrega' 
  | 'Financeiro' 
  | 'TikTok Shop — Produção' 
  | 'TikTok Shop — Performance' 
  | 'Geral';

export interface RecurrenceConfig {
  frequency: 'Diário' | 'Semanal' | 'Quinzenal' | 'Mensal';
  daysOfWeek: number[];
  endOption?: string;
  endDate?: string;
  maxOccurrences?: number;
  currentOccurrenceCount?: number;
}

export interface Task {
  id: string;
  description: string;
  goalId?: string;
  responsibleId: string;
  deadline: string;
  status: TaskStatus;
  priority: Priority;
  type?: TaskType;
  quantity?: number;
  isRecurring?: boolean;
  recurrence?: RecurrenceConfig;
  parentId?: string;
}

export interface AppState {
  users: User[];
  products: Product[];
  campaigns: Campaign[];
  adSets: AdSet[];
  creatives: Creative[];
  dailyMetrics: DailyMetric[];
  sales: Sale[];
  frustrationReasons: FrustrationReason[];
  goals: Goal[];
  tasks: Task[];
  transactions: Transaction[];
  cards: CardConfig[];
  debtContracts: DebtContract[];
  currentUser: User | null;
}

export interface AppContextType extends AppState {
  setCurrentUser: (user: User) => void;
  addSale: (sale: Sale) => void;
  updateSale: (sale: Sale) => void;
  deleteSale: (saleId: string) => void;
  addCampaign: (data: { name: string, productId: string }) => string;
  updateCampaign: (campaign: Campaign) => void;
  deleteCampaign: (campaignId: string) => void;
  addAdSet: (data: { name: string, campaignId: string }) => string;
  updateAdSet: (adSet: AdSet) => void;
  deleteAdSet: (adSetId: string) => void;
  addCreative: (data: { name: string, adSetId: string, format: string }) => string;
  updateCreative: (creative: Creative) => void;
  deleteCreative: (creativeId: string) => void;
  addMetric: (metric: DailyMetric) => void;
  updateMetric: (metric: DailyMetric) => void;
  deleteMetric: (metricId: string) => void;
  addTask: (task: Task) => void;
  updateTask: (task: Task) => void;
  deleteTask: (taskId: string) => void;
  toggleTaskStatus: (taskId: string, status: TaskStatus) => void;
  addGoal: (goal: Omit<Goal, 'id'>) => void;
  updateGoal: (goal: Goal) => void;
  deleteGoal: (goalId: string) => void;
  addUser: (user: Omit<User, 'id'>) => Promise<void>;
  updateUser: (user: User) => Promise<void>;
  deleteUser: (userId: string | number) => Promise<void>;
  addTransaction: (data: Omit<Transaction, 'id'>) => Promise<string>;
  updateTransaction: (transaction: Transaction) => Promise<void>;
  deleteTransaction: (id: string) => Promise<void>;
  addCard: (card: Omit<CardConfig, 'id'>) => void;
  updateCard: (card: CardConfig) => void;
  deleteCard: (id: string) => void;
  addDebtContract: (contract: Omit<DebtContract, 'id'>) => Promise<string>;
  updateDebtContract: (contract: DebtContract) => Promise<void>;
  deleteDebtContract: (id: string) => Promise<void>;
}
